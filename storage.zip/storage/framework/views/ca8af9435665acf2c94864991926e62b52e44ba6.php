<?php echo $__env->make('control.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Transactions</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <section class="content">
        <div class="container-fluid">


            <div class="row">
                <?php if(session()->has('message_update')): ?>                                
                    <div class="alert alert-success alert-dismissible col-12">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <strong><?php echo e(session()->get('message_update')); ?></strong>
                    </div>
                <?php endif; ?>            
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"></h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive table-striped p-0">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Balance</th>
                                        <th scope="col">Description</th>
                                        <th scope="col">Status</th>

                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                
                                        <tr>
                                            <td><?php echo e($transaction->user->firstname); ?> <?php echo e($transaction->user->lastname); ?></td>
                                            <td><?php echo e($transaction->type); ?></td>
                                            <td>$<?php echo e($transaction->amount); ?></td>
                                            <td>$<?php echo e($transaction->balance); ?></td>
                                            <td><?php echo e($transaction->description); ?></td>
                                            <td>
                                            <?php if($transaction->status == 0 && $transaction->description == "Credit Request"): ?>
                                                <span class="badge bg-warning">Pending</span>
                                            <?php elseif($transaction->status == 1): ?>
                                                <span class="badge bg-success">Success</span>
                                            <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($transaction->type == "Credit"): ?>
                                                <a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-<?php echo e($transaction->id); ?>" title="Fund User Account"><i class="fas fa-hand-holding-usd"></i></a>
                                                <?php elseif($transaction->type == "Debit"): ?>
                                                <a href="approve_transfer/<?php echo e($transaction->id); ?>" class="btn btn-success btn-sm"title="Approve"><i class="fas fa-check"></i></a>
                                                <a href="deny_transfer/<?php echo e($transaction->id); ?>" class="btn btn-danger btn-sm" title="Deny"><i class="fas fa-times"></i></a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <div class="modal fade" id="modal-<?php echo e($transaction->id); ?>">
                                        <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                            <h6 class="modal-title">Fund <?php echo e($transaction->rwallet_type); ?> Wallet for <?php echo e($transaction->user->firstname); ?> <?php echo e($transaction->user->lastname); ?></h6>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            </div>
                                            <div class="modal-body">
                                                <form role="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('fund_wallet')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Amount $</label>
                                                                <input type="text" class="form-control" placeholder="Enter Amount" name="amount" value="<?php echo e($transaction->amount); ?>" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Description</label>
                                                                <input type="text" class="form-control" placeholder="Enter TDescription" name="description" value="Credit Transaction">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Sender Wallet Type</label>
                                                                <input type="text" class="form-control" name="swallet_type" placeholder="Senders Wallet Type">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Sender Wallet <Address></Address></label>
                                                                <input type="text" class="form-control" name="swallet_address" placeholder="Senders Wallet Type">
                                                            </div>
                                                        </div>
                                                    

                                                        <input type="hidden" name="rwallet_type" value="<?php echo e($transaction->rwallet_type); ?>">
                                                        <input type="hidden" name="rwallet_address" value="<?php echo e($transaction->rwallet_address); ?>">
                                                        <input type="hidden" name="user_id" value="<?php echo e($transaction->user->id); ?>">
                                                        

                        
                                                        
                        
                        
                                                        <div class="col-9">
                                                            <div class="form-group">
                                                                <button type="submit" name="create" class="btn btn-primary">Save Changes</button>
                                                            </div>
                                                        </div>

                                                        <div class="col-3 justify-content-end">
                                                            <div class="form-group">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                        
                                                        
                        
                        
                                                    </div>
                                                </form>
                                            </div>
        
                                        </div>
                                        <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            
                            </table>
                        </div>
                        <!-- /.card-body -->

                            <div class="card-footer clearfix">
                                <nav class="pagination-block">
                                </nav>
                                
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php echo $__env->make('control.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/control/transactions.blade.php ENDPATH**/ ?>