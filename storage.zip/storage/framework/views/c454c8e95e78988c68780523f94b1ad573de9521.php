<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4>Invest</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Invest</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


                <div class="row justify-content-center">
                    
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="card">
                            <div class="card-body border text-center rounded">
                                <span class="font-size-18 text-uppercase">Bronze Pack</span>
                                <h2 class="mb-4 display-6 font-weight-bolder ">$50 - $499<small class="font-size-14 text-muted"></small></h2>
                                <ul class="list-unstyled line-height-4 mb-0">
                                    <li>5% Increase Monthly</li>
                                    <li>Customer Support</li>
                                    <li>Weekly Withdrawals</li>
                                </ul>
                                <button type="button" class="btn btn-primary btn-block mt-5" data-toggle="modal" data-target="#bronze">Get Pack</button>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="bronze" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Bronze Pack</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="post" action="<?php echo e(route('invest_money')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">From which Wallet</label>
                                        <select class="form-control" id="exampleFormControlSelect1" name="wallet" required>
                                            <option selected disabled value="">Choose Wallet</option>
                                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>                                        
                                    <div class="form-group">
                                        <label for="amount">Amount to Invest $:</label>
                                        <input type="text" class="form-control" id="amount" name="amount" required>
                                    </div>
                                    <input type="hidden" name="type" value="Bronze">
                                                                        
                                </div>
                                
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Invest Fund</button>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="card bg-primary text-white">
                            <div class="card-body border text-center rounded">
                                <span class="font-size-18 text-uppercase">Silver Pack</span>
                                <h2 class="mb-4 display-6 font-weight-bolder ">$500 - $999<small class="font-size-14 text-muted"></small></h2>
                                <ul class="list-unstyled line-height-4 mb-0 ">
                                    <li>10% Increase Monthly</li>
                                    <li>Customer Support</li>
                                    <li>Weekly Withdrawals</li>
                                </ul>
                                <button type="button" class="btn btn-light btn-block mt-5" data-toggle="modal" data-target="#silver">Get Pack</button>

                            </div>
                        </div>
                    </div>
                    
                    <div class="modal fade" id="silver" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Silver Pack</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="post" action="<?php echo e(route('invest_money')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">From which Wallet</label>
                                        <select class="form-control" id="exampleFormControlSelect1" name="wallet" required>
                                            <option selected disabled value="">Choose Wallet</option>
                                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                        
                                    <div class="form-group">
                                        <label for="amount">Amount to Invest $:</label>
                                        <input type="text" class="form-control" id="amount" name="amount" required>
                                    </div>
                                    <input type="hidden" name="type" value="Silver">
                                
                                        
                                </div>
                                
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Invest Fund</button>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="card">
                            <div class="card-body border text-center rounded">
                                <span class="font-size-18 text-uppercase">Gold Pack</span>
                                <h3 class="mb-4 display-6 font-weight-bolder ">Above $1000<small class="font-size-14 text-muted"></small></h3>
                                <ul class="list-unstyled line-height-4 mb-0">
                                    <li>20% Increase Monthly</li>
                                    <li>Customer Support</li>
                                    <li>Weekly Withdrawals</li>
                                </ul>
                                <button type="button" class="btn btn-primary btn-block mt-5" data-toggle="modal" data-target="#gold">Get Pack</button>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="gold" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Gold Pack</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="post" action="<?php echo e(route('invest_money')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">

                                    <div class="form-group">
                                        <label for="exampleFormControlSelect1">From which Wallet</label>
                                        <select class="form-control" id="exampleFormControlSelect1" name="wallet" required>
                                            <option selected disabled value="">Choose Wallet</option>
                                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->type); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                        
                                    <div class="form-group">
                                        <label for="amount">Amount to Invest $:</label>
                                        <input type="text" class="form-control" id="amount" name="amount" required>
                                    </div>
                                    <input type="hidden" name="type" value="Gold">
                                
                                        
                                </div>
                                
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Invest Fund</button>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <?php if(session()->has('message')): ?> 
                        <div class="alert alert-info alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <h5><i class="icon fas fa-envelope"></i> Message!</h5>
                            <?php echo e(session()->get('message')); ?>

                        </div>                              
                        <?php endif; ?>
                    </div>
                </div>




      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/investor.blade.php ENDPATH**/ ?>