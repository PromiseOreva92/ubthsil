<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
      <div class="row justify-content-left">
        <div class="col-xl-7 col-lg-9">
          <h1 class="" style="font-family:sans-serif">Your investment is Your Future, Your Future is our Concern</h1>
          <h2>Join millions who've already discovered smarter investing in multiple types of main_assets.</h2>
        </div>
      </div>
      <div class="text-left">
        <a href="signup" class="btn-get-started scrollto">Get Started</a>
      </div>

      <div class="row icon-boxes">
        <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="200">
          <div class="icon-box">
            <div class="icon"><i class="ri-stack-line"></i></div>
            <h4 class="title"><a href="">Invest in the Digital Economy</a></h4>
            <p class="description">Make Your investments in Crypto Assets. </p>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="300">
          <div class="icon-box" style="background:#019968;color:#fff">
            <div class="icon" style="color:#fff"><i class="ri-palette-line"></i></div>
            <h4 class="title"><a href="" style="color:#fff">Future Proof Your Portfolio</a></h4>
            <p class="description">Your Today is product of yesterday, Your tomorrow is a product of your today's actions</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="400">
          <div class="icon-box">
            <div class="icon"><i class="ri-command-line"></i></div>
            <h4 class="title"><a href="">Build a Financial Legacy</a></h4>
            <p class="description">Build a financial legacy for yourself and the next generation</p>
          </div>
        </div>

        <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="500">
          <div class="icon-box" style="background:#019968;color:#fff">
            <div class="icon" style="color:#fff"><i class="ri-fingerprint-line"></i></div>
            <h4 class="title"><a href="" style="color:#fff">Secure Your Future</a></h4>
            <p class="description">Your tomorrow can be secured today. Invest in diigital assets</p>
          </div>
        </div>

      </div>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About Us</h2>
          <p>Knowing More About this Company</p>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
            Since their inception, cryptocurrencies have taken the financial world by storm. With untold potential and incredible upside, investors around the world are seeking ways to capitalize on the technology powering these innovative currencies. For newcomers to the field or seasoned veterans, there is one company that stands out from the rest: ID-CAPITALS Investments.
            </p>
            
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
            Founded by a team of cutting-edge cryptocurrency experts, ID-CAPITALS has quickly positioned itself as a leader in the investment world. Through its cutting-edge investment strategies and innovative approach to the market, ID-CAPITALS is unlocking the power of cryptocurrencies for investors of all levels.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts section-bg">
      <div class="container">

        <div class="row justify-content-end">

          <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <span data-purecounter-start="0" data-purecounter-end="1210" data-purecounter-duration="10" class="purecounter"></span>
              <p>Happy Clients</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <span data-purecounter-start="0" data-purecounter-end="1101" data-purecounter-duration="10" class="purecounter"></span>
              <p>Recomendations</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <span data-purecounter-start="0" data-purecounter-end="3" data-purecounter-duration="10" class="purecounter"></span>
              <p>Years of experience</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-5 col-6 d-md-flex align-items-md-stretch">
            <div class="count-box">
              <span data-purecounter-start="0" data-purecounter-end="5" data-purecounter-duration="10" class="purecounter"></span>
              <p>Awards</p>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- End Counts Section -->

    <!-- ======= About Video Section ======= -->
    <section id="about-video" class="about-video">
      <div class="container" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-4 video-box align-self-baseline text-center" data-aos="fade-right" data-aos-delay="100" style="height: 400px;">
            <img src="main_assets/img/logo_main.jpg" alt="" class="img-fluid">
          </div>

          <div class="col-lg-6 pt-3 pt-lg-0 content" data-aos="fade-left" data-aos-delay="100">
            <h3>More About ID-CAPITALS.</h3>
            <p class="">
            At the heart of ID-CAPITALS are its investment strategies. Leveraging the latest technology and analytical tools, the team at ID-CAPITALS has developed a proprietary system for identifying the most promising cryptocurrencies and investment opportunities. From high-growth assets to stable investments, ID-CAPITALS is actively seeking out the very best options for their clients.

            </p>


            <p>
              Beyond its innovative strategies, ID-CAPITALS is known for its world-class customer service. With a team of experienced professionals standing by, investors can rest assured that they will receive prompt and attentive support whenever it is needed. Whether it is answering questions or providing updates on the latest investment opportunities, the team at ID-CAPITALS is there to assist every step of the way
            </p>

            <a href="about-idcapitals" class="btn-learn-more">Learn More</a>

          </div>

        </div>

      </div>
    </section><!-- End About Video Section -->

    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients section-bg">
      <div class="container">

        <div class="row">

            <div class="col-12">
                  <!-- TradingView Widget BEGIN -->
                  <div class="tradingview-widget-container">
                    <div class="tradingview-widget-container__widget"></div>
                    <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/" rel="noopener" target="_blank"><span class="blue-text">Markets today</span></a> by TradingView</div>
                    <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                    {
                    "symbols": [
                      {
                        "proName": "FOREXCOM:SPXUSD",
                        "title": "S&P 500"
                      },
                      {
                        "proName": "FOREXCOM:NSXUSD",
                        "title": "US 100"
                      },
                      {
                        "proName": "FX_IDC:EURUSD",
                        "title": "EUR/USD"
                      },
                      {
                        "proName": "BITSTAMP:BTCUSD",
                        "title": "Bitcoin"
                      },
                      {
                        "proName": "BITSTAMP:ETHUSD",
                        "title": "Ethereum"
                      },
                      {
                        "description": "USDT",
                        "proName": "CRYPTOCAP:USDT"
                      }
                    ],
                    "showSymbolLogo": true,
                    "colorTheme": "light",
                    "isTransparent": false,
                    "displayMode": "adaptive",
                    "locale": "en"
                  }
                    </script>
                  </div>
                  <!-- TradingView Widget END -->


            </div>

        </div>

      </div>
    </section><!-- End Clients Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Testimonials</h2>
          <p>Testimonials from Happy Clients</p>
        </div>

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I was initially hesitant to invest in the stock market, but ID-CAPITALS helped me understand the benefits and risks. They provide regular updates and analysis on my portfolio, which gives me confidence in my investments.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="main_assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                <h3>Saul Goodman</h3>
                <h4>Ceo &amp; Founder</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  What I appreciate most about ID-CAPITALS is their commitment to transparency and communication. They keep me informed about market trends and performance, and explain complex financial concepts in a way that's easy to understand..
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="main_assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                <h3>Sara Wilsson</h3>
                <h4>Designer</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I've recommended ID-CAPITALS to several friends and family members, and they've all had positive experiences. The team is professional, friendly, and genuinely cares about their clients' success.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="main_assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                <h3>Jena Karlis</h3>
                <h4>Store Owner</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  I've been working with ID-CAPITALS for several years now, and they've helped me achieve my financial goals. Their knowledgeable advisors provide personalized recommendations that are tailored to my unique needs and circumstances
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="main_assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                <h3>Matt Brandon</h3>
                <h4>Freelancer</h4>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Working with ID-CAPITALS has been a game-changer for my retirement planning. They helped me create a customized investment strategy that aligns with my long-term goals, and I feel confident that I'm on track for a comfortable retirement.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                <img src="main_assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                <h3>John Larson</h3>
                <h4>Entrepreneur</h4>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Crypto Market Cap</h2>
          <p>Top 13 Digital Assets arranged according to their Market Cap</p>
        </div>

        <div class="row">
          <div class="col-lg-12" style="500px">
                <!-- TradingView Widget BEGIN -->
                <div class="tradingview-widget-container">
                  <div class="tradingview-widget-container__widget"></div>
                  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/cryptocurrencies/prices-all/" rel="noopener" target="_blank"><span class="blue-text">Crypto markets</span></a> by TradingView</div>
                  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-screener.js" async>
                  {
                  "width": "100%",
                  "height": "700",
                  "defaultColumn": "overview",
                  "screener_type": "crypto_mkt",
                  "displayCurrency": "USD",
                  "colorTheme": "light",
                  "locale": "en"
                }
                  </script>
                </div>
                <!-- TradingView Widget END -->
          </div>
          

        </div>

      </div>
    </section><!-- End Sevices Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="zoom-in">
        <div class="text-center">
          <h3>Start Investing</h3>
          <p>Your tomorrow starts Now. Avail yourself an opportunity to secure your future by investing in digital assets. </p>
          <a class="cta-btn" href="#">Secure Your Future</a>
        </div>
      </div>
    </section><!-- End Cta Section -->

    <!-- ======= Portfolio Section ======= -->
    
    
    <!-- End Portfolio Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Team</h2>
          <p>Meet our Team Leads</p>
        </div>

        <div class="row">

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="member">
              <div class="member-img">
                <img src="main_assets/img/team/team-1.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Walter White</h4>
                <span>Chief Executive Officer</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="member">
              <div class="member-img">
                <img src="main_assets/img/team/team-2.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Sarah Jhonson</h4>
                <span>Product Manager</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="member">
              <div class="member-img">
                <img src="main_assets/img/team/team-3.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>William Anderson</h4>
                <span>CTO</span>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-flex align-items-stretch" data-aos="fade-up" data-aos-delay="400">
            <div class="member">
              <div class="member-img">
                <img src="main_assets/img/team/team-4.jpg" class="img-fluid" alt="">
                <div class="social">
                  <a href=""><i class="bi bi-twitter"></i></a>
                  <a href=""><i class="bi bi-facebook"></i></a>
                  <a href=""><i class="bi bi-instagram"></i></a>
                  <a href=""><i class="bi bi-linkedin"></i></a>
                </div>
              </div>
              <div class="member-info">
                <h4>Amanda Jepson</h4>
                <span>Accountant</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Pricing Section ======= -->
    <section id="packages" class="pricing">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Our Packages</h2>
          <p>The advantages of investing in Royal Digital Capitals Management doesnt end with pricing. There are also no limits on commissions</p>
        </div>

        <div class="row">

          <div class="col-lg-4 col-md-6" data-aos="zoom-im" data-aos-delay="100">
            <div class="box">
              <h3>Bronze Pack</h3>
              <h4><sup>$50-$499</sup></h4>
              <ul>
                <li>5% Increase Yearly</li>
                <li>Customer Support</li>
                <li>Weekly Withdrawals</li>
              </ul>
              <div class="btn-wrap">
                <a href="signup" class="btn-buy">Invest Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="100">
            <div class="box featured">
              <h3>Silver Pack</h3>
              <h4><sup>$500-$999</sup></h4>
              <ul>
                <li>10% Increase Yearly</li>
                <li>Customer Support</li>
                <li>Weekly Withdrawals</li>
              </ul>
              <div class="btn-wrap">
                <a href="signup" class="btn-buy">Invest Now</a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="100">
            <div class="box">
              <h3>Gold Pack</h3>
              <h4><sup>$1000 and Above</sup></h4>
              <ul>
                <li>20% Increase Yearly</li>
                <li>Customer Support</li>
                <li>Weekly Withdrawals</li>
              </ul>
              <div class="btn-wrap">
                <a href="signup" class="btn-buy">Invest Now</a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Pricing Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1">What is your track record of success in managing investments?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                <p>
                We have a proven track record of providing sound investment advice and managing investments that have yielded positive returns for our clients.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed"> Can I switch my investments between different types? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p>
                Yes, we provide flexibility for investors to switch investments as needed to align with their goals and risk tolerance.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed"> What happens if I need to withdraw my funds early?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                <p>
                Depending on the investment, there may be fees or penalties associated with early withdrawals. We can provide guidance on the implications of early withdrawals.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">What fees do you charge for your services? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                <p>
                Our fees vary depending on the investment option and account type. Please refer to our fee schedule for more information
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">How often will I receive updates on my investments?<i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
                You will receive regular updates on your investments, including performance reports and transaction confirmations.
                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p>Reach Out to Us via the Contact form or Any of our Solial Media Platforms</p>
        </div>

        <div>
          <iframe style="border:0; width: 100%; height: 270px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" allowfullscreen></iframe>
        </div>

        <div class="row mt-5">

          <div class="col-lg-4">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>A108 Adam Street, New York, NY 535022</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>info@idcapitals.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+1 5589 55488 55s</p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0">

            <form action="" method="post" role="form" class="php-email-form">
              <div class="row gy-2 gx-md-3">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
                <div class="form-group col-12">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
                </div>
                <div class="form-group col-12">
                  <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
                </div>
                <div class="my-3 col-12">
                  <div class="loading">Loading</div>
                  <div class="error-message"></div>
                  <div class="sent-message">Your message has been sent. Thank you!</div>
                </div>
                <div class="text-center col-12"><button type="submit">Send Message</button></div>
              </div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/index.blade.php ENDPATH**/ ?>