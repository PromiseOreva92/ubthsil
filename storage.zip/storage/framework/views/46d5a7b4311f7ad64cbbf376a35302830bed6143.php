<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</head>
<body style="font-family:sans-serif">


<div class="container">
    <div class="row">
        <div class="col-lg-12">
        <img src="<?php echo e(asset('public/document')); ?>/<?php echo e($document->doc_image); ?>" alt="" class="" style="width: 100%;">
        </div>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6" style="text-align:center">
                <h6 style="text-align:center;font-weight:bold"><?php echo e($transaction->comment); ?></h6>
                <img src="<?php echo e(asset('public/profile_signatures')); ?>/<?php echo e($transaction->user->signature); ?>" alt="signature" class="img-fluid" style="height:30px">
                <h6 style="text-align:center;font-weight:bold"><?php echo e($transaction->user->fullname); ?></h6>
                <h6 style="text-align:center;font-weight:bold"><?php echo e($transaction->user->designation); ?></h6>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
</div>
    
</body>
</html>
<script>
  window.addEventListener("load", window.print());
</script><?php /**PATH /home/drivdgre/ubthsil.com/resources/views/mydesk/document.blade.php ENDPATH**/ ?>