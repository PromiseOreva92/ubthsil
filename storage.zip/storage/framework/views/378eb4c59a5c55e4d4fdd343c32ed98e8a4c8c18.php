<div id="loading">
    <div id="loading-center">
    </div>
</div><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/template/preview.blade.php ENDPATH**/ ?>