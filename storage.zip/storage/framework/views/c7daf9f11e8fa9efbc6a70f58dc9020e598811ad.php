<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Update KYC</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">KYC</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


        <div class="row">
          <div class="col-md-12">

            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">KYC</h3>
                </div>
                <form class="card-body" method="post" enctype="multipart/form-data" action="<?php echo e(route('kyc_update')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row align-items-center">
                        <div class="col-md-6">
                            <div class="profile-img-edit">
                            <?php if(Auth::user()->photo == NULL): ?>
                            <img class="profile-pic" id="imgPreview" src="<?php echo e(asset('c_assets/images/user/user.png')); ?>" alt="profile-pic" style="width: 150px;height:150px;border-radius:100px">
                            <div class="p-image">
                                <div class="form-group">
                                    <label for="exampleInputFile" class="text-primary">Upload Your Photo</label>
                                    <div class="input-group col-3">
                                        <div class="custom-file">
                                            <input type="file" name="photo" class="custom-file-input" id="photo" accept="image/*" onchange="preview()" required>
                                            <label class="custom-file-label border border-primary bg-primary" for="exampleInputFile"><i class="fas fa-pen-alt upload-button"></i></label>
                                        </div>
                                    </div>
                                </div>
                                <!-- <input class="file-upload" type="file" accept="image/*" required name="photo" id="photo"> -->
                            </div>
                            <?php else: ?>
                            <img class="profile-pic" src="<?php echo e(asset('public/images')); ?>/<?php echo e(Auth::user()->photo); ?>" alt="profile-pic" style="width:150px;height:150px;">
                            <?php endif; ?>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="profile-img-edit">
                            <?php if(Auth::user()->id_photo == NULL): ?>
                            <img class="profile-pic" id="idPreview" src="<?php echo e(asset('c_assets/images/user/placeholder.png')); ?>" alt="profile-pic" style="height:150px;">
                            <div class="p-image">
                                
                                <div class="form-group">
                                    <label for="exampleInputFile" class="text-primary">Upload Your Document</label>
                                    <div class="input-group col-3">
                                        <div class="custom-file">
                                            <input type="file" name="id_photo" class="custom-file-input" id="id_photo" accept="image/*" onchange="preview2()" required>
                                            <label class="custom-file-label border border-primary bg-primary" for="exampleInputFile"><i class="fas fa-pen-alt upload-button"></i></label>
                                        </div>
                                        
                                    </div>
                                </div>


                                <div class="form-group">
                                  <label class="text-primary">Type of ID:</label>

                                  <select name="id_type" id="id_type" class="form-control" required>
                                          <option value="National ID">National ID</option>
                                          <option value="Passport">Passport</option>
                                          <option value="Drivers License">Drivers License</option>
                                          <option value="Other">Other</option>
                                  </select>
                                <!-- /.input group -->
                                </div>  

                                <div class="form-group">
                                    <label class="text-primary">ID Number:</label>

                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                        <span class="input-group-text bg-primary"><i class="fa fa-user"></i></span>
                                        </div>
                                        <input type="text" class="form-control" placeholder="Enter the Number Your ID" name="id_number" required>
                                    </div>
                                <!-- /.input group -->
                                </div>


                            </div>
                            <?php else: ?>
                            <img class="profile-pic" src="<?php echo e(asset('public/documents')); ?>/<?php echo e(Auth::user()->id_photo); ?>" alt="ID Photo" style="width:150px;height:150px;">
                            <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <script>



                            function preview(){
                              const file = document.getElementById('photo').files[0];
                                console.log(file);

                                if (file){
                                let reader = new FileReader();
                                reader.onload = function(event){
                                    console.log(event.target.result);
                                    document.getElementById("imgPreview").setAttribute('src', event.target.result);
                                }
                                reader.readAsDataURL(file);
                              } 
                            }

                            function preview2(){
                              const file = document.getElementById('id_photo').files[0];
                                console.log(file);

                                if (file){
                                let reader = new FileReader();
                                reader.onload = function(event){
                                    console.log(event.target.result);
                                    document.getElementById("idPreview").setAttribute('src', event.target.result);
                                }
                                reader.readAsDataURL(file);
                              } 
                            }

                    </script>                    
                    <div class="form-group">
                      <label class="text-primary">Firstname:</label>

                      <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text bg-primary"><i class="fa fa-user"></i></span>
                          </div>
                          <input type="text" class="form-control" name="firstname" value="<?php echo e(Auth::user()->firstname); ?>" readonly>
                      </div>
                    <!-- /.input group -->
                    </div>

                    <div class="form-group">
                    <label class="text-primary">Lastname:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-user"></i></span>
                        </div>
                        <input type="text" class="form-control" name="lastname" value="<?php echo e(Auth::user()->lastname); ?>" readonly>
                    </div>
                    <!-- /.input group -->
                    </div>


                    <div class="form-group">
                    <label class="text-primary">Email:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-envelope"></i></span>
                        </div>
                        <input type="text" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" readonly>
                    </div>
                    <!-- /.input group -->
                    </div> 

                    <div class="form-group">
                      <label class="text-primary">Gender:</label>

                      <select name="gender" id="gender" class="form-control">
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                      </select>
                    <!-- /.input group -->
                    </div>                
                    <div class="form-group">
                    <label class="text-primary">Phone:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-phone"></i></span>
                        </div>
                        <input type="text" class="form-control" name="phone" placeholder="Give us Your Phone Number" value="<?php echo e(Auth::user()->phone); ?>">
                    </div>
                    <!-- /.input group -->
                    </div>

                    <div class="form-group">
                    <label class="text-primary">Date of Birth:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-calendar-alt"></i></span>
                        </div>
                        <input type="date" class="form-control" name="dob" value="<?php echo e(Auth::user()->dob); ?>">
                    </div>
                    <!-- /.input group -->
                    </div>

                    <div class="form-group">
                    <label class="text-primary">Address:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-map-marker-alt"></i></span>
                        </div>
                        <input type="text" class="form-control" name="address" placeholder="Give us Your Address" value="<?php echo e(Auth::user()->address); ?>">
                    </div>
                    <!-- /.input group -->
                    </div>

                    <div class="form-group">
                    <label class="text-primary">City:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-map-marker-alt"></i></span>
                        </div>
                        <input type="text" class="form-control" name="city" placeholder="Give us Your City Name" value="<?php echo e(Auth::user()->city); ?>">
                    </div>
                    <!-- /.input group -->
                    </div>

                    <div class="form-group">
                    <label class="text-primary">State:</label>

                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text bg-primary"><i class="fa fa-map-marker-alt"></i></span>
                        </div>
                        <input type="text" class="form-control" name="state" value="<?php echo e(Auth::user()->state); ?>">
                    </div>
                    <!-- /.input group -->
                    </div>

                    <div class="form-group">
                    <label class="text-primary">Country:</label>

                        <select class="form-control" id="exampleFormControlSelect1" name="country" required>
                            <option value="" disabled selected>Select Country</option>
                            <option>	Afghanistan	</option>
                            <option>	Albania	</option>
                            <option>	Algeria	</option>
                            <option>	Andorra	</option>
                            <option>	Angola	</option>
                            <option>	Antigua and Barbuda	</option>
                            <option>	Argentina	</option>
                            <option>	Armenia	</option>
                            <option>	Austria	</option>
                            <option>	Azerbaijan	</option>
                            <option>	Bahrain	</option>
                            <option>	Bangladesh	</option>
                            <option>	Barbados	</option>
                            <option>	Belarus	</option>
                            <option>	Belgium	</option>
                            <option>	Belize	</option>
                            <option>	Benin	</option>
                            <option>	Bhutan	</option>
                            <option>	Bolivia	</option>
                            <option>	Bosnia and Herzegovina	</option>
                            <option>	Botswana	</option>
                            <option>	Brazil	</option>
                            <option>	Brunei	</option>
                            <option>	Bulgaria	</option>
                            <option>	Burkina Faso	</option>
                            <option>	Burundi	</option>
                            <option>	Cabo Verde	</option>
                            <option>	Cambodia	</option>
                            <option>	Cameroon	</option>
                            <option>	Canada	</option>
                            <option>	Central African Republic	</option>
                            <option>	Chad	</option>
                            <option>	Channel Islands	</option>
                            <option>	Chile	</option>
                            <option>	China	</option>
                            <option>	Colombia	</option>
                            <option>	Comoros	</option>
                            <option>	Congo	</option>
                            <option>	Costa Rica	</option>
                            <option>	Côte d'Ivoire	</option>
                            <option>	Croatia	</option>
                            <option>	Cuba	</option>
                            <option>	Cyprus	</option>
                            <option>	Czech Republic	</option>
                            <option>	Denmark	</option>
                            <option>	Djibouti	</option>
                            <option>	Dominica	</option>
                            <option>	Dominican Republic	</option>
                            <option>	DR Congo	</option>
                            <option>	Ecuador	</option>
                            <option>	Egypt	</option>
                            <option>	El Salvador	</option>
                            <option>	Equatorial Guinea	</option>
                            <option>	Eritrea	</option>
                            <option>	Estonia	</option>
                            <option>	Eswatini	</option>
                            <option>	Ethiopia	</option>
                            <option>	Faeroe Islands	</option>
                            <option>	Finland	</option>
                            <option>	France	</option>
                            <option>	French Guiana	</option>
                            <option>	Gabon	</option>
                            <option>	Gambia	</option>
                            <option>	Georgia	</option>
                            <option>	Germany	</option>
                            <option>	Ghana	</option>
                            <option>	Gibraltar	</option>
                            <option>	Greece	</option>
                            <option>	Grenada	</option>
                            <option>	Guatemala	</option>
                            <option>	Guinea	</option>
                            <option>	Guinea-Bissau	</option>
                            <option>	Guyana	</option>
                            <option>	Haiti	</option>
                            <option>	Holy See	</option>
                            <option>	Honduras	</option>
                            <option>	Hong Kong	</option>
                            <option>	Hungary	</option>
                            <option>	Iceland	</option>
                            <option>	India	</option>
                            <option>	Indonesia	</option>
                            <option>	Iran	</option>
                            <option>	Iraq	</option>
                            <option>	Ireland	</option>
                            <option>	Isle of Man	</option>
                            <option>	Israel	</option>
                            <option>	Italy	</option>
                            <option>	Jamaica	</option>
                            <option>	Japan	</option>
                            <option>	Jordan	</option>
                            <option>	Kazakhstan	</option>
                            <option>	Kenya	</option>
                            <option>	Kuwait	</option>
                            <option>	Kyrgyzstan	</option>
                            <option>	Laos	</option>
                            <option>	Latvia	</option>
                            <option>	Lebanon	</option>
                            <option>	Lesotho	</option>
                            <option>	Liberia	</option>
                            <option>	Libya	</option>
                            <option>	Liechtenstein	</option>
                            <option>	Lithuania	</option>
                            <option>	Luxembourg	</option>
                            <option>	Macao	</option>
                            <option>	Madagascar	</option>
                            <option>	Malawi	</option>
                            <option>	Malaysia	</option>
                            <option>	Maldives	</option>
                            <option>	Mali	</option>
                            <option>	Malta	</option>
                            <option>	Mauritania	</option>
                            <option>	Mauritius	</option>
                            <option>	Mayotte	</option>
                            <option>	Mexico	</option>
                            <option>	Moldova	</option>
                            <option>	Monaco	</option>
                            <option>	Mongolia	</option>
                            <option>	Montenegro	</option>
                            <option>	Morocco	</option>
                            <option>	Mozambique	</option>
                            <option>	Myanmar	</option>
                            <option>	Namibia	</option>
                            <option>	Nepal	</option>
                            <option>	Netherlands	</option>
                            <option>	Nicaragua	</option>
                            <option>	Niger	</option>
                            <option>	Nigeria	</option>
                            <option>	North Korea	</option>
                            <option>	North Macedonia	</option>
                            <option>	Norway	</option>
                            <option>	Oman	</option>
                            <option>	Pakistan	</option>
                            <option>	Panama	</option>
                            <option>	Paraguay	</option>
                            <option>	Peru	</option>
                            <option>	Philippines	</option>
                            <option>	Poland	</option>
                            <option>	Portugal	</option>
                            <option>	Qatar	</option>
                            <option>	Réunion	</option>
                            <option>	Romania	</option>
                            <option>	Russia	</option>
                            <option>	Rwanda	</option>
                            <option>	Saint Helena	</option>
                            <option>	Saint Kitts and Nevis	</option>
                            <option>	Saint Lucia	</option>
                            <option>	Saint Vincent and the Grenadines	</option>
                            <option>	San Marino	</option>
                            <option>	Sao Tome & Principe	</option>
                            <option>	Saudi Arabia	</option>
                            <option>	Senegal	</option>
                            <option>	Serbia	</option>
                            <option>	Seychelles	</option>
                            <option>	Sierra Leone	</option>
                            <option>	Singapore	</option>
                            <option>	Slovakia	</option>
                            <option>	Slovenia	</option>
                            <option>	Somalia	</option>
                            <option>	South Africa	</option>
                            <option>	South Korea	</option>
                            <option>	South Sudan	</option>
                            <option>	Spain	</option>
                            <option>	Sri Lanka	</option>
                            <option>	State of Palestine	</option>
                            <option>	Sudan	</option>
                            <option>	Suriname	</option>
                            <option>	Sweden	</option>
                            <option>	Switzerland	</option>
                            <option>	Syria	</option>
                            <option>	Taiwan	</option>
                            <option>	Tajikistan	</option>
                            <option>	Tanzania	</option>
                            <option>	Thailand	</option>
                            <option>	The Bahamas	</option>
                            <option>	Timor-Leste	</option>
                            <option>	Togo	</option>
                            <option>	Trinidad and Tobago	</option>
                            <option>	Tunisia	</option>
                            <option>	Turkey	</option>
                            <option>	Turkmenistan	</option>
                            <option>	Uganda	</option>
                            <option>	Ukraine	</option>
                            <option>	United Arab Emirates	</option>
                            <option>	United Kingdom	</option>
                            <option>	United States	</option>
                            <option>	Uruguay	</option>
                            <option>	Uzbekistan	</option>
                            <option>	Venezuela	</option>
                            <option>	Vietnam	</option>
                            <option>	Western Sahara	</option>
                            <option>	Yemen	</option>
                            <option>	Zambia	</option>
                            <option>	Zimbabwe	</option>
                        </select>
                    <!-- /.input group -->
                    </div>


                    <div class="form-group">
                        <button class="btn btn-primary">Update KYC</button>
                    </div>
                    

                </form>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>

        </div>


      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/kyc.blade.php ENDPATH**/ ?>