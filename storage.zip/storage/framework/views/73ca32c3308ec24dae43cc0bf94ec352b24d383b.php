<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h4><?php echo e($wallet->type); ?></h4>

                <p><?php echo e($wallet->balance); ?></p>
              </div>
              <div class="icon">
                <i class="fa fa-dollar-sign"></i>
              </div>
              <a href="mywallets" class="small-box-footer">View all Wallets <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h4>Total Money Invested</h4>

                <p><?php echo e($total_invested); ?></p>
              </div>
              <div class="icon">
                <i class="fa fa-chart-bar"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h4>Total Returns</h4>

                <p><?php echo e($total_returns); ?></p>
              </div>
              <div class="icon">
                <i class="fa fa-dollar-sign"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h4>Total funds</h4>

                <p><?php echo e($total_funds); ?></p>
              </div>
              <div class="icon">
                <i class="fa fa-hand-holding-usd"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->

        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->


    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Previous Transactions</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <?php if(count($transactions) > 0): ?>
                <table id="example1" class="table table-striped">
                  <thead>
                  <tr>
                    <th scope="col">Type</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Description</th>
                    <th scope="col">Date</th>
                    <th scope="col" class="text-center">Status</th>
                    <th>View</th>
                  </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($transaction->description !="Credit Request"): ?>
                            <?php if($transaction->type == "Credit"): ?>
                              <tr class="text-success text-bold">
                                  <td><?php echo e($transaction->type); ?></td>
                                  <td>$<?php echo e($transaction->amount); ?></td>
                                  <td><?php echo e($transaction->description); ?></td>
                                  <td><?php echo e(date('jS F Y, H:i a',strtotime($transaction->created_at))); ?></td>
                                  <td class="text-center">
                                    <?php if($transaction->status == 1): ?>
                                    <div class="badge badge-pill bg-success">Completed</div>
                                    <?php else: ?>
                                    <div class="badge badge-pill bg-warning">Pending</div> 
                                    <?php endif; ?>
                                  </td>
                                  <td class="text-primary"><a class="fa fa-clipboard" style="font-size:1.5em !important;cursor:pointer" data-toggle="modal" data-target="#docs-<?php echo e($transaction->id); ?>"></a></td>

                                    <div class="modal fade" id="docs-<?php echo e($transaction->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                  <h5 class="modal-title" id="exampleModalLabel">Transaction Details</h5>
                                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                  </button>
                                              </div>
                                            
                                              <div class="modal-body">
                                                  
                                                  <p>
                                                    <strong>Transaction Type: </strong>
                                                    <?php echo e($transaction->type); ?>

                                                  </p>  
                                                  <p>
                                                    <strong>Amount: </strong>
                                                    $<?php echo e($transaction->amount); ?>

                                                  </p>
                                                  <p>
                                                    <strong>Balance: </strong>
                                                    $<?php echo e($transaction->balance); ?>

                                                  </p> 
                                                  <p>
                                                    <strong>Description: </strong>
                                                    <?php echo e($transaction->description); ?>

                                                  </p>

                                                  <p>
                                                    <strong>Date: </strong>
                                                    <?php echo e(date('jS F Y, H:i a',strtotime($transaction->created_at))); ?>

                                                  </p> 
                                                                                    
                                              </div>
                                                
                                              <div class="modal-footer">
                                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                
                                              </div>
                                            
                                            </div>
                                        </div>
                                    </div>
                              </tr>
                            <?php elseif($transaction->type == "Debit"): ?>
                                <tr class="text-danger text-bold">
                                  <td><?php echo e($transaction->type); ?></td>
                                  <td>$<?php echo e($transaction->amount); ?></td>
                                  <td><?php echo e($transaction->description); ?></td>
                                  <td><?php echo e(date('jS F Y, H:i a',strtotime($transaction->created_at))); ?></td>
                                  <td class="text-center">
                                    <?php if($transaction->status == 1): ?>
                                    <div class="badge badge-pill bg-success">Successful</div>
                                    <?php else: ?>
                                    <div class="badge badge-pill bg-warning">Pending</div> 
                                    <?php endif; ?>
                                  </td>
                                  <td class="text-primary"><a class="fa fa-clipboard" style="font-size:1.5em !important;cursor:pointer" data-toggle="modal" data-target="#docs-<?php echo e($transaction->id); ?>"></a></td>

                                    <div class="modal fade" id="docs-<?php echo e($transaction->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                              <div class="modal-header">
                                                  <h5 class="modal-title" id="exampleModalLabel">Transaction Details</h5>
                                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                                  </button>
                                              </div>
                                            
                                              <div class="modal-body">
                                                  
                                                  <p>
                                                    <strong>Transaction Type: </strong>
                                                    <?php echo e($transaction->type); ?>

                                                  </p>  
                                                  <p>
                                                    <strong>Amount: </strong>
                                                    $<?php echo e($transaction->amount); ?>

                                                  </p>
                                                  <p>
                                                    <strong>Balance: </strong>
                                                    $<?php echo e($transaction->balance); ?>

                                                  </p> 
                                                  <p>
                                                    <strong>Description: </strong>
                                                    <?php echo e($transaction->description); ?>

                                                  </p>

                                                  <p>
                                                    <strong>Date: </strong>
                                                    <?php echo e(date('jS F Y, H:i a',strtotime($transaction->created_at))); ?>

                                                  </p> 
                                                                                    
                                              </div>
                                                
                                              <div class="modal-footer">
                                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                
                                              </div>
                                            
                                            </div>
                                        </div>
                                    </div>
                              </tr>
                            <?php endif; ?>
                          <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  <tfoot>
                  <tr>
                      <th scope="col">Type</th>
                      <th scope="col">Amount</th>
                      <th scope="col">Description</th>
                      <th scope="col">Date</th>
                      <th scope="col" class="text-center">Status</th>
                  </tr>
                  </tfoot>
                </table>
                <?php else: ?>
                  <h4>You have no previous transactions</h4>
                <?php endif; ?>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->    
  </div>

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/index.blade.php ENDPATH**/ ?>