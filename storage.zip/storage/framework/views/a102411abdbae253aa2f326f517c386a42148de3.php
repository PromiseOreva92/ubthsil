<!doctype html>
<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>Vito - Responsive Bootstrap 4 Admin Dashboard Template</title>
      <!-- Favicon -->
      <link rel="shortcut icon" href="images/favicon.ico" />
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('c_assets/css/bootstrap.min.css')); ?>">
      <!-- Chart list Js -->
      <link rel="stylesheet" href="<?php echo e(asset('c_assets/js/chartist/chartist.min.css')); ?>">
      <!-- Typography CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('c_assets/css/typography.css')); ?>">
      <!-- Style CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('c_assets/css/style.css')); ?>">
      <!-- Responsive CSS -->
      <link rel="stylesheet" href="<?php echo e(asset('c_assets/css/responsive.css')); ?>">
   </head>

<?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/template/header.blade.php ENDPATH**/ ?>