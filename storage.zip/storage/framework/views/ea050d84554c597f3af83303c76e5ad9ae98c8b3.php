<?php echo $__env->make('mydesk.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <?php echo $__env->make('mydesk.template.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- loader END -->
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Sidebar  -->
         <?php echo $__env->make('mydesk.template.side-top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- TOP Nav Bar END -->
         <!-- Page Content  -->
         <div id="content-page" class="content-page">
            <div class="container-fluid">
               <div class="row">



                  <div class="col-lg-12">
                     <div class="iq-edit-list-data">
                        <?php if(session()->has('message')): ?> 
                           <div class="alert text-white bg-primary" role="alert">
                              <div class="iq-alert-text"><?php echo e(session()->get('message')); ?></div>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <i class="ri-close-line"></i>
                              </button>
                           </div>                               
                        <?php endif; ?>                                    

                        <div>
                           <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
                               <div class="iq-card">

                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Mandate Information</h4>
                                    </div>
                                 </div>

                                 <div class="iq-card-body">
                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('upload_mandate')); ?>">
                                       <?php echo csrf_field(); ?>
                                       <div class="form-group row align-items-center">
                                          <div class="col-md-12">
                                             <div class="profile-img-edit">
                                                <img id="docPreview" src="<?php echo e(asset('c_assets/images/user/document.jpg')); ?>" style="height:150px;" alt="document-pic">
                                                <div class="p-image">
                                                  <i class="ri-pencil-line upload-button"></i>
                                                  <input class="file-upload" type="file" accept="image/*" required name="document" id="document">
                                                  
                                                </div>
                                    
                                             </div>
                                          </div>
                                       </div>

                                       <script>
                                          $(document).ready(()=>{
                                                $('#document').change(function(){
                                                   const file = this.files[0];
                                                   console.log(file);
                                                   if (file){
                                                   let reader = new FileReader();
                                                   reader.onload = function(event){
                                                      console.log(event.target.result);
                                                      $('#docPreview').attr('src', event.target.result);
                                                   }
                                                   reader.readAsDataURL(file);
                                                   }
                                                });
                                             });

                                       </script>
                                       <div class="row align-items-center">
                                          <div class="form-group col-sm-6">
                                             <label for="fname">Document Title/Caption:</label>
                                             <input type="text" class="form-control" name="title" required>
                                          </div>
                                          <div class="form-group col-sm-6">
                                             <label for="lname">Comments/Extra Info:</label>
                                             <input type="text" class="form-control" name="comment" required>
                                          </div>
                                          
                                         

                                    
                                          
                                         
                                          
                                       </div>
                                       <button type="submit" class="btn btn-primary mr-2">Upload Doc</button>
                                    </form>
                                 </div>
                              </div>
                           </div>



                        </div>
                     </div>
                  </div>
               </div>
               
               <div class="row">
                     <div class="col-lg-12">
                        <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
                           <div class="iq-card-header d-flex justify-content-between">
                              <div class="iq-header-title">
                                 <h4 class="card-title">All Mandates</h4>
                              </div>
                              <div class="iq-card-header-toolbar d-flex align-items-center">
                                 <div class="dropdown">
                                    <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                                    <i class="ri-more-fill"></i>
                                    </span>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">

                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="iq-card-body">
                              <?php if(count($documents)==0): ?>
                                    <h6 class="ms-4" style="font-weight:bold">No Available Mandate</h6>
                              <?php else: ?>
                                 
                                    <div class="table-responsive">
                                       <table class="table mb-0 table-borderless">
                                          <thead>
                                             
                                             <tr>
                                                <th scope="col">S/N</th> 
                                                <th scope="col">Title</th>
                                
                                                <th scope="col" class="text-center">Action</th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                            <?php
                                                $count = 1;
                                            ?>
                                          <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($count); ?></td>
                                                   <td><?php echo e($document->title); ?></td>
                                                   <?php if(Auth::user()->designation == "ICT" ||Auth::user()->designation == "Admin" ): ?>
                                                   <td class="text-center">
                                                           <a href="delete_doc/<?php echo e($document->id); ?>" class="btn btn-sm btn-danger">
                                                                 Delete Document
                                                           </a>
                                                   
                                                   </td>
                                                   <?php endif; ?>
                                                   
                                                </tr>
                                            <?php
                                                $count++;
                                            ?>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                       </table>
                                    </div>
                                 
                              <?php endif; ?>
                           </div>
                        </div>
                     </div>

                  </div>
            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <?php echo $__env->make('mydesk.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/drivdgre/ubthsil.com/resources/views/mydesk/upload_mandate.blade.php ENDPATH**/ ?>