<div style="text-center">
    <img src="<?php echo e(url('images/logo_main.jpg')); ?>" alt="" class="img-fluid">
</div>
<h2 style="text-center">Document Received!</h2>
<p style="margin-top:20px;font-size:16px">Dear <?php echo e($fullname); ?></p>
<p style="margin-top:20px;font-size:16px">A document has been forwarded to your desk please login and attend to it</p>

<p style="font-size:16px"> 
Feel free contact our the site admin if your are having any challenge.
</p>
<p style="margin-top:20px;font-size:16px">
    Warm Regards,<br>
    <strong>Support Team</strong>
</p><?php /**PATH C:\xampp\htdocs\ubithsil.com\resources\views/emails/document_mail.blade.php ENDPATH**/ ?>