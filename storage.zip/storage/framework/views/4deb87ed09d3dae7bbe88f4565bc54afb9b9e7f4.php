<?php echo $__env->make('control.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Clients</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


<section class="content">
    <div class="container-fluid">




        <div class="row">
                <?php if(session()->has('message')): ?> 
                <div class="alert alert-info alert-dismissible col-12">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fas fa-check"></i> Message Feedback!</h5>
                  <?php echo e(session()->get('message')); ?>

                </div>                              
                <?php endif; ?>
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"> Clients</h3>


                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive table-striped p-0">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th>KYC Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="modal fade" id="message-modal-<?php echo e($user->id); ?>">
                                    <div class="modal-dialog">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h4 class="modal-title">Message User</h4>
                                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                          </button>
                                        </div>
                                        <div class="modal-body">
                                            <form role="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('message_user')); ?>">
                                                <?php echo csrf_field(); ?> 
                                                <div class="row">
                                                    

                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Message</label>
                                                            <textarea name="message" id="message" cols="30" rows="3" class="form-control"></textarea>
                                                        </div>
                                                    </div>                        
                                                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                    
                                                    
                    
                    
                                                    <div class="col-9">
                                                        <div class="form-group">
                                                            <button type="submit" name="create" class="btn btn-primary">Save Changes</button>
                                                        </div>
                                                    </div>

                                                    <div class="col-3 justify-content-end">
                                                        <div class="form-group">
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                        </div>
                                                    </div>
                    
                                                    
                    
                    
                                                </div>
                                            </form>
                                        </div>
      
                                      </div>
                                      <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                </div>  
                                <div class="modal fade" id="fund-modal-<?php echo e($user->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title">Fund Wallet for <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h6>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form role="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('fund_wallet')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Amount $</label>
                                                                <input type="text" class="form-control" placeholder="Enter Amount" name="amount" required>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Description</label>
                                                                <input type="text" class="form-control" placeholder="Enter Description" name="description" value="Credit Transaction">
                                                            </div>
                                                        </div>
                                                        
                                                        

                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Receiving Wallet</label>
                                                                <select name="rwallet_type" id="" class="form-control">
                                                                    <option value="Bitcoin">Bitcoin</option>
                                                                    <option value="Ethereum">Ethereum</option>
                                                                    <option value="USDT">USDT</option>
                                                                    <option value="Cadano">Cadano</option>
                                                                </select>
                                                            </div>
                                                        </div>

                                                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                                        
                                                        

                        
                                                        
                        
                        
                                                        <div class="col-9">
                                                            <div class="form-group">
                                                                <button type="submit" name="create" class="btn btn-primary">Save Changes</button>
                                                            </div>
                                                        </div>

                                                        <div class="col-3 justify-content-end">
                                                            <div class="form-group">
                                                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                                            </div>
                                                        </div>
                        
                                                        
                        
                        
                                                    </div>
                                                </form>
                                            </div>
        
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                        <!-- /.modal-dialog -->
                                </div>
                                <div class="modal fade" id="wallet-modal-<?php echo e($user->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title">Wallet Details for <?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h6>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body" id="feedback">

                                            </div>
        
                                        </div>
                                        <!-- /.modal-content -->
                                    </div>
                                        <!-- /.modal-dialog -->
                                </div>                                                                                              
                                    <tr>
                                        <td><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <?php if($user->kyc_status == 0): ?>
                                            <span class="badge bg-warning">Not Complete</span>
                                            <?php else: ?>
                                            <span class="badge bg-success">Complete</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="" class="btn btn-success btn-sm" data-toggle="modal" data-target="#fund-modal-<?php echo e($user->id); ?>" title="Fund User Account"><i class="fas fa-hand-holding-usd"></i></a>
                                            <a href="" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#message-modal-<?php echo e($user->id); ?>" title="Message User"><i class="fas fa-envelope"></i></a>
                                            <a href="" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#wallet-modal-<?php echo e($user->id); ?>" title="View Wallet" onclick="fetchwallet('<?php echo e($user->id); ?>')"><i class="fas fa-wallet"></i></a>
                                            <a href="/delete_user/<?php echo e($user->id); ?>" class="btn btn-danger btn-sm" title="Delete User"><i class="fas fa-trash-alt"></i></a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                           
                        </table>
                        


                    </div>
                    <!-- /.card-body -->

                        <div class="card-footer clearfix">
                            <nav class="pagination-block">
                            </nav>
                            
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php echo $__env->make('control.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
function fetchwallet(user_id){

    
    const xmlhttp = new XMLHttpRequest();
    xmlhttp.onload = function() {
        alert();
        arr = this.responseText;
        jsonArray = JSON.parse(arr)
        str="";
       for(var x=0; x < jsonArray.length;x++){
           str +=  "<div><strong>"+jsonArray[x].type+"</strong>: $"+jsonArray[x].balance+"</div>";
       } 
      document.getElementById("feedback").innerHTML = str;

    }
    xmlhttp.open("GET", "fetchwallets/" + user_id);
    xmlhttp.send();
}
</script><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/control/clients.blade.php ENDPATH**/ ?>