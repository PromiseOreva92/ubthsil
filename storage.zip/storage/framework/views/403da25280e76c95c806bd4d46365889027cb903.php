<?php echo $__env->make('mycustomer.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <?php echo $__env->make('mycustomer.template.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- loader END -->
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Sidebar  -->
         <?php echo $__env->make('mycustomer.template.side-top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- TOP Nav Bar END -->
         <!-- Page Content  -->
         <div id="content-page" class="content-page">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="iq-card">
                        <div class="iq-card-body p-0">
                           <div class="iq-edit-list">
                              <ul class="iq-edit-profile d-flex nav nav-pills">

                                 <li class="col-md-6 p-0">
                                    <a class="nav-link active" data-toggle="pill" href="#personal-information">
                                       Update KYC
                                    </a>
                                 </li>
                                 <li class="col-md-6 p-0">
                                    <a class="nav-link" data-toggle="pill" href="#chang-pwd">
                                       Change Password
                                    </a>
                                 </li>

                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>


                  <div class="col-lg-12">
                     <div class="iq-edit-list-data">
                        <?php if(session()->has('message')): ?> 
                           <div class="alert text-white bg-primary" role="alert">
                              <div class="iq-alert-text"><?php echo e(session()->get('message')); ?></div>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <i class="ri-close-line"></i>
                              </button>
                           </div>                               
                        <?php endif; ?>                                    

                        <div class="tab-content">
                           <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
                               <div class="iq-card">

                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Personal Information</h4>
                                    </div>
                                 </div>

                                 <div class="iq-card-body">
                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('kyc_update')); ?>">
                                       <?php echo csrf_field(); ?>
                                       <div class="form-group row align-items-center">
                                          <div class="col-md-12">
                                             <div class="profile-img-edit">
                                                <?php if(Auth::user()->photo == NULL): ?>
                                                <img class="profile-pic" id="imgPreview" src="<?php echo e(asset('c_assets/images/user/user.png')); ?>" alt="profile-pic">
                                                <div class="p-image">
                                                  <i class="ri-pencil-line upload-button"></i>
                                                  <input class="file-upload" type="file" accept="image/*" required name="photo" id="photo">
                                                </div>
                                                <?php else: ?>
                                                <img class="profile-pic" src="<?php echo e(asset('public/images')); ?>/<?php echo e(Auth::user()->photo); ?>" alt="profile-pic">
                                                <?php endif; ?>
                                             </div>
                                          </div>
                                       </div>

                                       <script>
                                          $(document).ready(()=>{
                                                $('#photo').change(function(){
                                                   const file = this.files[0];
                                                   console.log(file);
                                                   if (file){
                                                   let reader = new FileReader();
                                                   reader.onload = function(event){
                                                      console.log(event.target.result);
                                                      $('#imgPreview').attr('src', event.target.result);
                                                   }
                                                   reader.readAsDataURL(file);
                                                   }
                                                });
                                             });

                                       </script>
                                       <div class="row align-items-center">
                                          <div class="form-group col-sm-6">
                                             <label for="fname">First Name:</label>
                                             <input type="text" class="form-control" name="firstname" value="<?php echo e($user->firstname); ?>" disabled>
                                          </div>
                                          <div class="form-group col-sm-6">
                                             <label for="lname">Last Name:</label>
                                             <input type="text" class="form-control" name="lastname" value="<?php echo e($user->lastname); ?>" disabled>
                                          </div>
                                          <div class="form-group col-sm-12">
                                             <label for="uname">Email:</label>
                                             <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" disabled>
                                          </div>
                                          
                                          <div class="form-group col-sm-12">
                                             <label class="d-block">Gender:</label>

                                             <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadio6" name="gender" class="custom-control-input" checked="" value="Male">
                                                <label class="custom-control-label" for="customRadio6"> Male </label>
                                             </div>
                                             <div class="custom-control custom-radio custom-control-inline">
                                                <input type="radio" id="customRadio7" name="gender" class="custom-control-input" value="Female">
                                                <label class="custom-control-label" for="customRadio7"> Female </label>
                                             </div>


                                          </div>

                                          <div class="form-group col-sm-12">
                                             <label for="dob">Date Of Birth:</label>
                                             <input type="date" class="form-control" name="dob" value="<?php echo e($user->dob); ?>" required>
                                          </div>
                                          <div class="form-group col-sm-12">
                                             <label>Address:</label>
                                             <textarea class="form-control" name="address" rows="5" style="line-height: 22px;" required><?php echo e(Auth::user()->address); ?></textarea>                                       </textarea>
                                          </div>

                                          <div class="form-group col-sm-6">
                                             <label for="cname">City:</label>
                                             <input type="text" class="form-control" id="cname" name="city" required value="<?php echo e(Auth::user()->city); ?>">
                                          </div>

                                          <div class="form-group col-sm-6">
                                             <label for="cname">State/Division:</label>
                                             <input type="text" class="form-control" id="cname" name="state" required value="<?php echo e(Auth::user()->state); ?>">
                                          </div>
                                          <div class="form-group col-sm-12">
                                             <label>Your Country:</label>
                                             <select class="form-control" id="exampleFormControlSelect1" name="country" required">
                                                   <option value="" disabled selected>Select Country</option>
                                                   <option>	Afghanistan	</option>
                                                   <option>	Albania	</option>
                                                   <option>	Algeria	</option>
                                                   <option>	Andorra	</option>
                                                   <option>	Angola	</option>
                                                   <option>	Antigua and Barbuda	</option>
                                                   <option>	Argentina	</option>
                                                   <option>	Armenia	</option>
                                                   <option>	Austria	</option>
                                                   <option>	Azerbaijan	</option>
                                                   <option>	Bahrain	</option>
                                                   <option>	Bangladesh	</option>
                                                   <option>	Barbados	</option>
                                                   <option>	Belarus	</option>
                                                   <option>	Belgium	</option>
                                                   <option>	Belize	</option>
                                                   <option>	Benin	</option>
                                                   <option>	Bhutan	</option>
                                                   <option>	Bolivia	</option>
                                                   <option>	Bosnia and Herzegovina	</option>
                                                   <option>	Botswana	</option>
                                                   <option>	Brazil	</option>
                                                   <option>	Brunei	</option>
                                                   <option>	Bulgaria	</option>
                                                   <option>	Burkina Faso	</option>
                                                   <option>	Burundi	</option>
                                                   <option>	Cabo Verde	</option>
                                                   <option>	Cambodia	</option>
                                                   <option>	Cameroon	</option>
                                                   <option>	Canada	</option>
                                                   <option>	Central African Republic	</option>
                                                   <option>	Chad	</option>
                                                   <option>	Channel Islands	</option>
                                                   <option>	Chile	</option>
                                                   <option>	China	</option>
                                                   <option>	Colombia	</option>
                                                   <option>	Comoros	</option>
                                                   <option>	Congo	</option>
                                                   <option>	Costa Rica	</option>
                                                   <option>	Côte d'Ivoire	</option>
                                                   <option>	Croatia	</option>
                                                   <option>	Cuba	</option>
                                                   <option>	Cyprus	</option>
                                                   <option>	Czech Republic	</option>
                                                   <option>	Denmark	</option>
                                                   <option>	Djibouti	</option>
                                                   <option>	Dominica	</option>
                                                   <option>	Dominican Republic	</option>
                                                   <option>	DR Congo	</option>
                                                   <option>	Ecuador	</option>
                                                   <option>	Egypt	</option>
                                                   <option>	El Salvador	</option>
                                                   <option>	Equatorial Guinea	</option>
                                                   <option>	Eritrea	</option>
                                                   <option>	Estonia	</option>
                                                   <option>	Eswatini	</option>
                                                   <option>	Ethiopia	</option>
                                                   <option>	Faeroe Islands	</option>
                                                   <option>	Finland	</option>
                                                   <option>	France	</option>
                                                   <option>	French Guiana	</option>
                                                   <option>	Gabon	</option>
                                                   <option>	Gambia	</option>
                                                   <option>	Georgia	</option>
                                                   <option>	Germany	</option>
                                                   <option>	Ghana	</option>
                                                   <option>	Gibraltar	</option>
                                                   <option>	Greece	</option>
                                                   <option>	Grenada	</option>
                                                   <option>	Guatemala	</option>
                                                   <option>	Guinea	</option>
                                                   <option>	Guinea-Bissau	</option>
                                                   <option>	Guyana	</option>
                                                   <option>	Haiti	</option>
                                                   <option>	Holy See	</option>
                                                   <option>	Honduras	</option>
                                                   <option>	Hong Kong	</option>
                                                   <option>	Hungary	</option>
                                                   <option>	Iceland	</option>
                                                   <option>	India	</option>
                                                   <option>	Indonesia	</option>
                                                   <option>	Iran	</option>
                                                   <option>	Iraq	</option>
                                                   <option>	Ireland	</option>
                                                   <option>	Isle of Man	</option>
                                                   <option>	Israel	</option>
                                                   <option>	Italy	</option>
                                                   <option>	Jamaica	</option>
                                                   <option>	Japan	</option>
                                                   <option>	Jordan	</option>
                                                   <option>	Kazakhstan	</option>
                                                   <option>	Kenya	</option>
                                                   <option>	Kuwait	</option>
                                                   <option>	Kyrgyzstan	</option>
                                                   <option>	Laos	</option>
                                                   <option>	Latvia	</option>
                                                   <option>	Lebanon	</option>
                                                   <option>	Lesotho	</option>
                                                   <option>	Liberia	</option>
                                                   <option>	Libya	</option>
                                                   <option>	Liechtenstein	</option>
                                                   <option>	Lithuania	</option>
                                                   <option>	Luxembourg	</option>
                                                   <option>	Macao	</option>
                                                   <option>	Madagascar	</option>
                                                   <option>	Malawi	</option>
                                                   <option>	Malaysia	</option>
                                                   <option>	Maldives	</option>
                                                   <option>	Mali	</option>
                                                   <option>	Malta	</option>
                                                   <option>	Mauritania	</option>
                                                   <option>	Mauritius	</option>
                                                   <option>	Mayotte	</option>
                                                   <option>	Mexico	</option>
                                                   <option>	Moldova	</option>
                                                   <option>	Monaco	</option>
                                                   <option>	Mongolia	</option>
                                                   <option>	Montenegro	</option>
                                                   <option>	Morocco	</option>
                                                   <option>	Mozambique	</option>
                                                   <option>	Myanmar	</option>
                                                   <option>	Namibia	</option>
                                                   <option>	Nepal	</option>
                                                   <option>	Netherlands	</option>
                                                   <option>	Nicaragua	</option>
                                                   <option>	Niger	</option>
                                                   <option>	Nigeria	</option>
                                                   <option>	North Korea	</option>
                                                   <option>	North Macedonia	</option>
                                                   <option>	Norway	</option>
                                                   <option>	Oman	</option>
                                                   <option>	Pakistan	</option>
                                                   <option>	Panama	</option>
                                                   <option>	Paraguay	</option>
                                                   <option>	Peru	</option>
                                                   <option>	Philippines	</option>
                                                   <option>	Poland	</option>
                                                   <option>	Portugal	</option>
                                                   <option>	Qatar	</option>
                                                   <option>	Réunion	</option>
                                                   <option>	Romania	</option>
                                                   <option>	Russia	</option>
                                                   <option>	Rwanda	</option>
                                                   <option>	Saint Helena	</option>
                                                   <option>	Saint Kitts and Nevis	</option>
                                                   <option>	Saint Lucia	</option>
                                                   <option>	Saint Vincent and the Grenadines	</option>
                                                   <option>	San Marino	</option>
                                                   <option>	Sao Tome & Principe	</option>
                                                   <option>	Saudi Arabia	</option>
                                                   <option>	Senegal	</option>
                                                   <option>	Serbia	</option>
                                                   <option>	Seychelles	</option>
                                                   <option>	Sierra Leone	</option>
                                                   <option>	Singapore	</option>
                                                   <option>	Slovakia	</option>
                                                   <option>	Slovenia	</option>
                                                   <option>	Somalia	</option>
                                                   <option>	South Africa	</option>
                                                   <option>	South Korea	</option>
                                                   <option>	South Sudan	</option>
                                                   <option>	Spain	</option>
                                                   <option>	Sri Lanka	</option>
                                                   <option>	State of Palestine	</option>
                                                   <option>	Sudan	</option>
                                                   <option>	Suriname	</option>
                                                   <option>	Sweden	</option>
                                                   <option>	Switzerland	</option>
                                                   <option>	Syria	</option>
                                                   <option>	Taiwan	</option>
                                                   <option>	Tajikistan	</option>
                                                   <option>	Tanzania	</option>
                                                   <option>	Thailand	</option>
                                                   <option>	The Bahamas	</option>
                                                   <option>	Timor-Leste	</option>
                                                   <option>	Togo	</option>
                                                   <option>	Trinidad and Tobago	</option>
                                                   <option>	Tunisia	</option>
                                                   <option>	Turkey	</option>
                                                   <option>	Turkmenistan	</option>
                                                   <option>	Uganda	</option>
                                                   <option>	Ukraine	</option>
                                                   <option>	United Arab Emirates	</option>
                                                   <option>	United Kingdom	</option>
                                                   <option>	United States	</option>
                                                   <option>	Uruguay	</option>
                                                   <option>	Uzbekistan	</option>
                                                   <option>	Venezuela	</option>
                                                   <option>	Vietnam	</option>
                                                   <option>	Western Sahara	</option>
                                                   <option>	Yemen	</option>
                                                   <option>	Zambia	</option>
                                                   <option>	Zimbabwe	</option>
                                             </select>
                                          </div>
                                          <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                          
                                       </div>
                                       <button type="submit" class="btn btn-primary mr-2">Complete KYC</button>
                                    </form>
                                 </div>
                              </div>
                           </div>


                           <div class="tab-pane fade" id="chang-pwd" role="tabpanel">
                               <div class="iq-card">
                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Change Password</h4>
                                    </div>
                                 </div>
                                 <div class="iq-card-body">
                                    <form method="post" action="<?php echo e(route('change_password')); ?>">
                                      <?php echo csrf_field(); ?> 
                                       <div class="form-group">
                                          <label for="cpass">Current Password:</label>
                                          <input type="Password" class="form-control" id="cpass" name="cpass" required>
                                       </div>
                                       <div class="form-group">
                                          <label for="npass">New Password:</label>
                                          <input type="Password" class="form-control" id="npass" name="npass" required>
                                       </div>
                                       <div class="form-group">
                                          <label for="vpass">Verify Password:</label>
                                             <input type="Password" class="form-control" id="vpass" name="vpass" required>
                                       </div>
                                       <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                       <button type="reset" class="btn iq-bg-danger">Cancle</button>
                                    </form>
                                 </div>
                              </div>
                           </div>



                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <?php echo $__env->make('mycustomer.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/selfservice.blade.php ENDPATH**/ ?>