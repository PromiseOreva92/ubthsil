<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4>Receive</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Receive</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


        <div class="row">
          <div class="col-md-12">

            <div class="card card-primary">
                <div class="card-header">
                    <h4 class="card-title">Receive Funds</h4>
                </div>
                <form class="card-body" method="post" action="<?php echo e(route('receive_money')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(session()->has('message')): ?> 
                        <p>Scan the QR Code to receive funds</p>
                        <div class="text-center">
                            <?php echo QrCode::size(300)->generate(session()->get('message')); ?>

                            <p><?php echo e(session()->get('message')); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="form-group">
                            <label for="exampleFormControlSelect1">To which Wallet</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="rwallet" required>
                            <option selected="" disabled="">Choose Wallet</option>
                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="amount">Amount to be Received:</label>
                            <input type="text" class="form-control" id="amount" name="amount" required>
                        </div>
                                 
                        <div class="form-group">
                            <button class="btn btn-primary">Submit</button>
                        </div>

                    <?php endif; ?> 



                    

                </form>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>

        </div>




      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/receiver.blade.php ENDPATH**/ ?>