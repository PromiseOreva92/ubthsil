<?php echo $__env->make('mydesk.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <?php echo $__env->make('mydesk.template.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- loader END -->
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Sidebar  -->
         <?php echo $__env->make('mydesk.template.side-top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- TOP Nav Bar END -->
         <!-- Page Content  -->
         <div id="content-page" class="content-page">
            <div class="container-fluid">
               <div class="row">



                  <div class="col-lg-12">
                     <div class="iq-edit-list-data">
                        <?php if(session()->has('message')): ?> 
                           <div class="alert text-white bg-primary" role="alert">
                              <div class="iq-alert-text"><?php echo e(session()->get('message')); ?></div>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <i class="ri-close-line"></i>
                              </button>
                           </div>                               
                        <?php endif; ?>                                    

                        <div>
                           <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
                               <div class="iq-card">

                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">New Staff Information</h4>
                                    </div>
                                 </div>

                                 <div class="iq-card-body">
                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('create_account')); ?>">
                                       <?php echo csrf_field(); ?>
                                        <div class="row align-items-center">
                                          <div class="form-group col-sm-6">
                                             <label for="fname">Staff Fullname:</label>
                                             <input type="text" class="form-control" name="fullname" required>
                                          </div>
                                          <div class="form-group col-sm-6">
                                             <label for="lname">Staff Email:</label>
                                             <input type="email" class="form-control" name="email" required>
                                          </div>
                                          <div class="form-group col-sm-6">
                                             <label for="fname">Staff Phone Number:</label>
                                             <input type="text" class="form-control" name="phone" required>
                                          </div>
                                          <div class="form-group col-sm-6">
                                             <label for="fname">Staff Designation:</label>
                                             <input type="text" class="form-control" name="designation" required>
                                          </div>

                                          <div class="form-group col-sm-6">
                                             <label for="fname">Account Type:</label>
                                             <select name="user_type" id="" class="form-control" required>
                                                <option value="" selected disabled>Select Account Type</option>
                                                <option>User</option>
                                                <option>Admin</option>
                                                <option>Secretary</option>
                                                <option>Registry</option>
                                             </select>
                                          </div>
                                       </div>
                                       <button type="submit" class="btn btn-primary mr-2">Create Account</button>
                                    </form>
                                 </div>
                              </div>
                           </div>



                        </div>
                     </div>
                  </div>
               </div>

               <div class="row">
                     <div class="col-lg-12">
                        <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
                           <div class="iq-card-header d-flex justify-content-between">
                              <div class="iq-header-title">
                                 <h4 class="card-title">All User</h4>
                              </div>
                              <div class="iq-card-header-toolbar d-flex align-items-center">
                                 <div class="dropdown">
                                    <span class="dropdown-toggle text-primary" id="dropdownMenuButton5" data-toggle="dropdown">
                                    <i class="ri-more-fill"></i>
                                    </span>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton5">

                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="iq-card-body">
                              <?php if(count($users)==0): ?>
                                    <h6 class="ms-4" style="font-weight:bold">No User Available</h6>
                              <?php else: ?>
                                 
                                    <div class="table-responsive">
                                       <table class="table mb-0 table-borderless">
                                          <thead>
                                             
                                             <tr>
                                                <th scope="col">Fullname</th>
                                                <!-- <th scope="col">Email</th> -->
                                                <th scope="col">Phone</th>
                                                <th scope="col">Designation</th>
                                                <!-- <th scope="col">Account Type</th> -->
                                                <th scope="col" class="text-center">Action</th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                   <td><?php echo e($user->fullname); ?></td>
                                                   <!-- <td><?php echo e($user->email); ?></td> -->
                                                   <td><?php echo e($user->phone); ?></td>
                                                   <td><?php echo e($user->designation); ?></td>
                                                   <!-- <td><?php echo e($user->user_type); ?></td> -->
                                                   <td class="text-center">
                                                   <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal-<?php echo e($user->id); ?>">
                                                         Edit
                                                   </button>
                                                      <div id="modal-<?php echo e($user->id); ?>" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"  aria-hidden="true">
                                                         <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                               <div class="modal-header">
                                                                  <h5 class="modal-title" id="exampleModalCenteredScrollableTitle">Edit User</h5>
                                                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                  <span aria-hidden="true">×</span>
                                                                  </button>
                                                               </div>
                                                               <form action="<?php echo e(route('edit_user')); ?>" method="post" enctype="multipart/form-data">
                                                                  <?php echo csrf_field(); ?>
                                                                  <div class="modal-body">
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="comment">Fullname:</label>
                                                                        <input type="text" class="form-control" name="fullname" value="<?php echo e($user->fullname); ?>">
                                                                     </div>
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="comment">Email:</label>
                                                                        <input type="text" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                                                                     </div>
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="comment">Phone:</label>
                                                                        <input type="text" class="form-control" name="phone" value="<?php echo e($user->phone); ?>">
                                                                     </div>
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="comment">Designation:</label>
                                                                        <input type="text" class="form-control" name="designation" value="<?php echo e($user->designation); ?>">
                                                                     </div>
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="fname">Account Type:</label>
                                                                        <select name="user_type" id="" class="form-control" required>
                                                                           <option value="" selected disabled>Select Account Type</option>
                                                                           <option>User</option>
                                                                           <option>Admin</option>
                                                                           <option>Secretary</option>
                                                                           <option>Registry</option>
                                                                        </select>
                                                                     </div>

                                                                     <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                                                  </div>
                                                                  <div class="modal-footer">
                                                                     <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                     <button type="submit" class="btn btn-primary">Edit</button>
                                                                  </div>
                                                               </form>
                                                            </div>
                                                         </div>
                                                      </div>                                                      
                                                    <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#modalpsw-<?php echo e($user->id); ?>">
                                                       Password
                                                    </button>
                                                        <div id="modalpsw-<?php echo e($user->id); ?>" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog"  aria-hidden="true">
                                                         <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                               <div class="modal-header">
                                                                  <h5 class="modal-title" id="exampleModalCenteredScrollableTitle">Change User Password</h5>
                                                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                  <span aria-hidden="true">×</span>
                                                                  </button>
                                                               </div>
                                                               <form action="<?php echo e(route('change_userpassword')); ?>" method="post" enctype="multipart/form-data">
                                                                  <?php echo csrf_field(); ?>
                                                                  <div class="modal-body">
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="comment">New Password:</label>
                                                                        <input type="text" class="form-control" name="npass">
                                                                     </div>
                                                                     <div class="form-group col-sm-12">
                                                                        <label for="comment">Confirm Password:</label>
                                                                        <input type="text" class="form-control" name="vpass">
                                                                     </div>
                                                                    
                                                                     <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                                                  </div>
                                                                  <div class="modal-footer">
                                                                     <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                     <button type="submit" class="btn btn-primary">Change Password</button>
                                                                  </div>
                                                               </form>
                                                            </div>
                                                         </div>
                                                      </div>                                                      


                                                    <a class="btn btn-sm btn-danger" href="delete_user/<?php echo e($user->id); ?>">
                                                         Delete
                                                   </a>

                                                   </td>
                                                </tr>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                       </table>
                                    </div>
                                 
                              <?php endif; ?>
                           </div>
                        </div>
                     </div>

                  </div>
            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <?php echo $__env->make('mydesk.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ubithsil.com\resources\views/mydesk/create_accounts.blade.php ENDPATH**/ ?>