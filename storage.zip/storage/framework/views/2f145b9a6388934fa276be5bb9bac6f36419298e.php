<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4>History</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">History</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h4 class="card-title">History</h4>
                    </div>
                    <div class="card-body">
                            <div class="table-responsive">
                                 <table class="table mb-0 table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Type</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Date</th>
                                            <th scope="col" class="text-center">Status</th>
                                            <th>View</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if($transaction->description !="Credit Request"): ?>
                                            <tr>
                                                <td><?php echo e($transaction->type); ?></td>
                                                <td>$<?php echo e($transaction->amount); ?></td>
                                                <td><?php echo e($transaction->description); ?></td>
                                                <td> <?php echo e(date('jS F Y, H:i a',strtotime($transaction->created_at))); ?></td>
                                                <td class="text-center">
                                                   <?php if($transaction->status == 1): ?>
                                                   <div class="badge badge-pill bg-success">Completed</div>
                                                   <?php else: ?>
                                                   <div class="badge badge-pill bg-warning">Pending</div> 
                                                   <?php endif; ?>
                                                </td>
                                                <td class="text-primary"><a class="fa fa-clipboard" style="font-size:1.5em !important;cursor:pointer" data-toggle="modal" data-target="#docs-<?php echo e($transaction->id); ?>"></a></td>

                                                <div class="modal fade" id="docs-<?php echo e($transaction->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                          <div class="modal-header">
                                                              <h5 class="modal-title" id="exampleModalLabel">Transaction Details</h5>
                                                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                              <span aria-hidden="true">&times;</span>
                                                              </button>
                                                          </div>
                                                        
                                                          <div class="modal-body">
                                                              
                                                               <p>
                                                                <strong>Transaction Type: </strong>
                                                                <?php echo e($transaction->type); ?>

                                                              </p>  
                                                              <p>
                                                                <strong>Amount: </strong>
                                                                $<?php echo e($transaction->amount); ?>

                                                              </p>
                                                              <p>
                                                                <strong>Balance: </strong>
                                                                $<?php echo e($transaction->balance); ?>

                                                              </p> 
                                                              <p>
                                                                <strong>Description: </strong>
                                                                <?php echo e($transaction->description); ?>

                                                              </p>

                                                              <p>
                                                                <strong>Date: </strong>
                                                                <?php echo e(date('jS F Y, H:i a',strtotime($transaction->created_at))); ?>

                                                              </p> 
                                                                                                 
                                                          </div>
                                                            
                                                          <div class="modal-footer">
                                                              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            
                                                          </div>
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                             </tr>
                                          <?php endif; ?>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                 </table>
                            </div>


                    </div>
                </div>
            </div>
        </div>


      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/transactions.blade.php ENDPATH**/ ?>