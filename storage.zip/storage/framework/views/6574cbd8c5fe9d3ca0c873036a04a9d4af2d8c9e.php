<?php echo $__env->make('mydesk.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <?php echo $__env->make('mydesk.template.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- loader END -->
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Sidebar  -->
         <?php echo $__env->make('mydesk.template.side-top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- TOP Nav Bar END -->
         <!-- Page Content  -->
         <div id="content-page" class="content-page">
            <div class="container-fluid">
                <div class="row">
                <div class="col-lg-6">
                     <div class="iq-edit-list-data">
                                                          

                        <div>
                           <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
                               <div class="iq-card">

                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Uploaded Document</h4>
                                    </div>
                                 </div>

                                 <div class="iq-card-body">
                                    <img src="<?php echo e(asset('public/document')); ?>/<?php echo e($document->doc_image); ?>" alt="" class="img-fluid">
                                 </div>
                              </div>
                           </div>



                        </div>
                     </div>
                  </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <h5>Document Summary</h5>
                        <div class="table-responsive-sm">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-center" scope="col">#</th>
                                        <th class="text-center" scope="col">Signatory and Comment</th>
                                        <th class="text-center" scope="col">Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php
                                          $count = 1;
                                      ?>  
                                    
                                    <tr>
                                        <th class="text-center" scope="row"><?php echo e($count); ?></th>
                                        <td>
                                            <h6 class="mb-0"><?php echo e($transaction->user->fullname); ?> (<?php echo e($transaction->user->designation); ?>):- </h6>
                                            <p class="mb-0"><b><?php echo e($transaction->comment); ?> </b></p>
                                        </td>
                                        
                                        <td class="text-center"><b><?php echo e(date('jS F Y',strtotime($transaction->created_at))); ?> </b></td>
                                    </tr>
                                    <?php
                                        $count++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
 
                    </div>
                    <div class="col-sm-6"></div>
                    <div class="col-sm-6 text-right">
                        <a href="../print_document/<?php echo e($document->id); ?>" class="btn btn-link mr-3" rel="noopener" target="_blank" ><i class="ri-printer-line"></i> Download Print</button>
                    </div>
                                        <div class="col-sm-12 mt-5">
                                            <b class="text-danger">Notes:</b>
                                            <p>All Signatures will be embeded as part of the document.</p>
                                        </div>
                   
                </div>
            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <?php echo $__env->make('mydesk.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ubtsil\resources\views/mydesk/view_document.blade.php ENDPATH**/ ?>