<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-md-12">



            <!-- About Me Box -->
            <div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">About Me</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="text-center">
                    <?php if(Auth::user()->photo != NULL): ?>
                    <img src="<?php echo e(asset('public/images')); ?>/<?php echo e(Auth::user()->photo); ?>" class="img-fluid rounded mr-3 w-25" alt="user">
                    <?php else: ?>
                    <img src="<?php echo e(asset('c_assets/images/user/user.png')); ?>" class="img-fluid rounded mr-3" alt="user" >
                    <?php endif; ?>  
                </div>

                <h3 class="profile-username text-center text-primary"><?php echo e(Auth::user()->firstname); ?> <?php echo e(Auth::user()->lastname); ?></h3>

                <p class="text-muted text-center text-primary"><?php echo e(Auth::user()->email); ?></p>

                <hr>

                <p class="text-primary">
                  <strong class="mr-2"><i class="fas fa-calendar-alt mr-1"></i> Joined: </strong>
                  <?php echo e(date('jS F ,Y', strtotime(Auth::user()->created_at))); ?>

                </p>

                <hr>

                

                <p class="text-primary">
                  <strong class="mr-2"><i class="fas fa-envelope mr-1"></i> Email:</strong>
                  <?php echo e(Auth::user()->email); ?>

                </p>

                <hr>


                <?php if(Auth::user()->kyc_status == 0): ?>
                      <p class="text-primary">
                        <strong class="mr-2"><i class="fas fa-phone mr-1"></i> Phone Number:</strong>
                        <?php echo e(Auth::user()->phone); ?>

                      </p>
                      <hr>
                      <p class="text-primary">
                        <strong class="mr-2"><i class="fas fa-user mr-1"></i> Gender:</strong>
                        <?php echo e(Auth::user()->gender); ?>

                      </p>
                      <hr>
                      <p class="text-primary">
                        <strong class="mr-2"><i class="fas fa-calendar-alt mr-1"></i> Date of Birth:</strong>
                        <?php echo e(date('jS F Y',strtotime(Auth::user()->bob))); ?>

                      </p> 
                      <hr> 
                      <p class="text-primary">
                        <strong class="mr-2"><i class="fas fa-map-marker-alt mr-1"></i> Address:</strong>
                        <?php echo e(Auth::user()->address); ?>

                      </p>
                      <hr>
                      
                      <p class="text-primary">
                        <strong class="mr-2"><i class="fas fa-map-marker-alt mr-1"></i> State:</strong>
                        <?php echo e(Auth::user()->state); ?>

                      </p>
                      <hr>

                      <p class="text-primary">
                        <strong class="mr-2"><i class="fas fa-map-marker-alt mr-1"></i> Country:</strong>
                        <?php echo e(Auth::user()->country); ?>

                      </p>
                      <hr>

                <?php else: ?>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <h5><i class="icon fas fa-envelope"></i> Message!</h5>
                                <p>Your KYC has not been updated. Please <a href="my-kyc">Update your KYC</a> </p>
                            </div>                              
                        </div>
                    </div>                      
                <?php endif; ?>


                <hr>


              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/profile.blade.php ENDPATH**/ ?>