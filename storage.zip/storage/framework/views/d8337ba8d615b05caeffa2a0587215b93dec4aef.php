<?php echo $__env->make('mydesk.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <?php echo $__env->make('mydesk.template.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- loader END -->
      <!-- Wrapper Start -->
      <div class="wrapper">
      <!-- Sidebar  -->
      <?php echo $__env->make('mydesk.template.side-top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- TOP Nav Bar END -->
      <!-- Page Content  -->
   <div id="content-page" class="content-page">
      <div class="container-fluid">
         <div class="row">
            <div class="col-sm-12">
                  <div class="iq-card">
                        <div class="iq-card-header d-flex justify-content-between">
                           <div class="iq-header-title">
                              <h4 class="card-title">Archived Documents</h4>
                           </div>
                        </div>
                        <div class="iq-card-body">
                           <p>List of All Documents in Archive</p>
                           <div class="table-responsive">
                                 <table class="table mb-0 table-borderless">
                                    <thead>
                                        <tr>
                                            <th scope="col">Document Title</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($document->title); ?></td>
                                                <td>                        
                                                   <a href="print_document/<?php echo e($document->id); ?>" class="btn btn-link mr-3" rel="noopener" target="_blank" >
                                                        <i class="ri-printer-line"></i> 
                                                        Download Print
                                                    </a>
                                                    <a href="unarchive/<?php echo e($document->id); ?>" class="btn btn-sm btn-danger">
                                                        UnArchive
                                                    </a> 
                                                </td>
                                                
                                             </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                 </table>
                            </div>
                           </div>
                     </div>
            </div>
         </div>

      </div>
   </div>
   </div>
   <!-- Wrapper END -->
    <!-- Footer -->
    <?php echo $__env->make('mydesk.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ubtsil\resources\views/mydesk/archived_documents.blade.php ENDPATH**/ ?>