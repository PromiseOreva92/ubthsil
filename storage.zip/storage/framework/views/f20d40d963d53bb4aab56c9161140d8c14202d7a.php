<?php echo $__env->make('control.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Investments</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <section class="content">
        <div class="container-fluid">


            <div class="row">
            
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"></h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive table-striped p-0">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Package</th>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Date</th>
                                        <!-- <th>Action</th> -->
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                
                                        <tr>
                                            <td><?php echo e($investment->user->firstname); ?> <?php echo e($investment->user->lastname); ?></td>
                                            <td><?php echo e($investment->type); ?></td>
                                            <td>$<?php echo e($investment->amount); ?></td>
                                            <td><?php echo e(date('jS F Y',strtotime($investment->created_at))); ?></td>
                                        </tr>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            
                            </table>
                        </div>
                        <!-- /.card-body -->

                            <div class="card-footer clearfix">
                                <nav class="pagination-block">
                                </nav>
                                
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php echo $__env->make('control.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/control/investments.blade.php ENDPATH**/ ?>