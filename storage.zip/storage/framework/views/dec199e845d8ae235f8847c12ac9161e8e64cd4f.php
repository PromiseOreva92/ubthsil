<div style="text-center">
    <img src="<?php echo e(url('images/logo_main.jpg')); ?>" alt="" class="img-fluid">
</div>
<h2 style="text-center">Sign In Notice!</h2>
<p style="margin-top:20px;font-size:16px">Dear <?php echo e($firstname); ?> <?php echo e($lastname); ?></p>
<p style="margin-top:20px;font-size:16px">You have Successfully Logged into your account</p>
<p style="font-size:16px"> 

Please if you did not initiate this action, <br> contact our customer support on support@idcapitals.com as your account might have been compromised.
</p>
<p style="margin-top:20px;font-size:16px">
    Warm Regards,<br>
    <strong>ID-CAPITALS Support Team</strong>
</p><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/emails/signin_mail.blade.php ENDPATH**/ ?>