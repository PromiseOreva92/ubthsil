<div style="text-center">
    <img src="<?php echo e(url('images/logo_main.jpg')); ?>" alt="" class="img-fluid">
</div>
<h2 style="text-center">Verify Yourself!</h2>
<p style="margin-top:20px;font-size:16px">Dear <?php echo e($firstname); ?> <?php echo e($lastname); ?></p>
<p style="margin-top:20px;font-size:16px">Please Enter the OTP code below to verify yourself</p>

<h1 style="margin-top:10px;text-align:center;color:brown;"><?php echo e($otp); ?></h1>
<p style="font-size:16px"> 
Feel free contact our customer support on support@idcapitals.com if your are having any challenge.
</p>
<p style="margin-top:20px;font-size:16px">
    Warm Regards,<br>
    <strong>Support Team</strong>
</p><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/emails/otp_mail.blade.php ENDPATH**/ ?>