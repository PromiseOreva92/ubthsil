<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4>My Investments</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">My Investments</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h4 class="card-title">Investments</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                          <?php if(count($investments) < 1): ?>
                            <h5>You have not made any Investment</h5>
                          <?php else: ?>
                                 <table class="table mb-0 table-striped">
                                    <thead>
                                        <tr>
                                            <th scope="col">Type</th>
                                            <th scope="col">Amount</th>
                                            <th>Returns</th>
                                            <th scope="col">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($investment->type); ?></td>
                                                <td>$<?php echo e($investment->amount); ?></td>
                                                <td>$<?php echo e($investment->returns); ?></td>
                                                <td><?php echo e(date('jS F Y',strtotime($investment->created_at))); ?></td>
                  
                                             </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                 </table>
                            <?php endif; ?>
                            </div>


                           </div>
                    </div>
                </div>
            </div>
        </div>


      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/investments.blade.php ENDPATH**/ ?>