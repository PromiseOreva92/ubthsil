<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4>Send Money</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Send Money</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


        <div class="row">
          <div class="col-md-12">

            <div class="card card-primary">
                <div class="card-header">
                    <h4 class="card-title">Send Money</h4>
                </div>
                <form class="card-body" method="post" action="<?php echo e(route('send_money')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php if(session()->has('message')): ?> 
                    <div class="alert alert-info alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <h5><i class="icon fas fa-check"></i> Message!</h5>
                      <?php echo e(session()->get('message')); ?>

                    </div>                              
                    <?php endif; ?>
                    <div class="form-group">
                            <label for="exampleFormControlSelect1">From which Wallet</label>
                            <select class="form-control" id="exampleFormControlSelect1" name="swallet" required>
                            <option selected="" disabled="">Choose Wallet</option>
                            <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($wallet->id); ?>"><?php echo e($wallet->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                
                    <div class="form-group">
                        <label for="email"> To Wallet Address:</label>
                        <input type="text" class="form-control" id="address" name="rwallet_address" required>
                    </div>

                    
                    <div class="form-group">
                        <label for="amount">Amount:</label>
                        <input type="text" class="form-control" id="amount" name="amount" required>
                    </div>

                    <div class="form-group">
                        <label for="amount">Description:</label>
                        <input type="text" class="form-control" id="description" name="description">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Submit</button>



                    

                </form>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>

        </div>




      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/sender.blade.php ENDPATH**/ ?>