<?php echo $__env->make("mycustomer.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h4>My Wallets</h4>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">My Wallets</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">


        <div class="row">
          <div class="col-md-12">

                <?php if(session()->has('message')): ?> 
                <div class="alert alert-info alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fas fa-check"></i> Message!</h5>
                  <?php echo e(session()->get('message')); ?>

                </div>                              
                <?php endif; ?>
            <div class="card card-primary">
                <div class="card-header">
                    <h4 class="card-title">Add Wallet</h4>
                </div>

                <form class="card-body" method="post" action="<?php echo e(route('create_wallet')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleFormControlSelect1">Select Wallet</label>
                        <select class="form-control" id="exampleFormControlSelect1" name="type" required>
                          <option selected disabled value="">Choose a Wallet</option>
                          <option>Bitcoin</option>
                          <option>Ethereum</option>
                          <option>Cadano</option>
                          <option>USDT</option>
                        </select>
                    </div>
                
                    
                    <div class="form-group">
                        <button class="btn btn-primary">Create Wallet</button>
                    </div>



                    

                </form>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

          </div>

        </div>


        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header">
                        <h4 class="card-title">Wallet List</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                                <table class="table mb-0 table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">Type</th>
                                        <th scope="col">Balance</th>
                                        <th scope="col" class="text-center">Status</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($wallet->type); ?></td>
                                        <td>$<?php echo e($wallet->balance); ?></td>
                                        <td class="text-center"><div class="badge badge-pill iq-bg-success">Active</div></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php echo $__env->make("mycustomer.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/mycustomer/wallets.blade.php ENDPATH**/ ?>