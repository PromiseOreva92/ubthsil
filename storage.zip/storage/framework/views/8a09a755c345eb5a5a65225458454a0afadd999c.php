<?php echo $__env->make('mydesk.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <body>
      <!-- loader Start -->
      <?php echo $__env->make('mydesk.template.preview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- loader END -->
      <!-- Wrapper Start -->
      <div class="wrapper">
         <!-- Sidebar  -->
         <?php echo $__env->make('mydesk.template.side-top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- TOP Nav Bar END -->
         <!-- Page Content  -->
         <div id="content-page" class="content-page">
            <div class="container-fluid">
               <div class="row">



                  <div class="col-lg-12">
                     <div class="iq-edit-list-data">
                        <?php if(session()->has('message')): ?> 
                           <div class="alert text-white bg-primary" role="alert">
                              <div class="iq-alert-text"><?php echo e(session()->get('message')); ?></div>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <i class="ri-close-line"></i>
                              </button>
                           </div>                               
                        <?php endif; ?>                                    

                        <div>
                           <div class="tab-pane fade active show" id="personal-information" role="tabpanel">
                               <div class="iq-card">

                                 <div class="iq-card-header d-flex justify-content-between">
                                    <div class="iq-header-title">
                                       <h4 class="card-title">Upload Signature</h4>
                                    </div>
                                 </div>

                                 <div class="iq-card-body">
                                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('upload_signature')); ?>">
                                       <?php echo csrf_field(); ?>
                                       
                                       <div class="row align-items-center">



                                          <div class="form-group row align-items-center">
                                             <div class="col-md-12">
                                             <!-- <label for="uname">Upload your Signature Here:</label> <br> -->
                                                <div class="profile-img-edit">
                                                   <?php if(Auth::user()->signature == NULL): ?>
                                                   <img id="signaturePreview" src="<?php echo e(asset('c_assets/images/user/signature.png')); ?>" style="height:150px" alt="profile-pic">
                                                   <div class="p-image">
                                                         <i class="ri-pencil-line upload-button"></i>
                                                         <input class="file-upload" type="file" accept="image/*" required name="signature" id="signature">
                                                   </div>
                                                   <?php else: ?>
                                                   <img  src="<?php echo e(asset('public/profile_signatures')); ?>/<?php echo e(Auth::user()->signature); ?>" style="height:150px;" alt="signature-pic">
                                                   <?php endif; ?>
                                                </div>
                                             </div>
                                          </div>

                                       <script>
                                          $(document).ready(()=>{
                                             
                                                $('#signature').change(function(){
                                                   const file = this.files[0];
                                                   console.log(file);
                                                   if (file){
                                                   let reader = new FileReader();
                                                   reader.onload = function(event){
                                                        
                                                      console.log(event.target.result);
                                                      $('#signaturePreview').attr('src', event.target.result);
                                                   }
                                                   reader.readAsDataURL(file);
                                                   }
                                                });
                                             });

                                       </script>
                                          
                                         

                                    
                                          
                                          <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                          
                                       </div>
                                       <button type="submit" class="btn btn-primary mr-2">Update Profile</button>
                                    </form>
                                 </div>
                              </div>
                           </div>



                        </div>
                     </div>
                  </div>
               </div>


            </div>
         </div>
      </div>
      <!-- Wrapper END -->
      <!-- Footer -->
      <?php echo $__env->make('mydesk.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ubithsil.com\resources\views/mydesk/signature_upload.blade.php ENDPATH**/ ?>