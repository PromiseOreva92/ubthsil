<div id="loading">
    <div id="loading-center">
    </div>
</div><?php /**PATH C:\xampp\htdocs\ubtsil\resources\views/mydesk/template/preview.blade.php ENDPATH**/ ?>