      <!-- Wrapper END -->
      <!-- Footer -->
      <footer class="iq-footer">
         <div class="container-fluid">
            <div class="row">
               <div class="col-lg-6">
                  <ul class="list-inline mb-0">
                     <li class="list-inline-item"><a href="privacy-policy.html">Privacy Policy</a></li>
                     <li class="list-inline-item"><a href="terms-of-service.html">Terms of Use</a></li>
                  </ul>
               </div>
               <div class="col-lg-6 text-right">
                  Copyright 2024 <a href="#">Drivespace</a> All Rights Reserved.
               </div>
            </div>
         </div>
      </footer>

            <!-- Footer END -->
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      
      <script src="<?php echo e(asset('c_assets/js/jquery.min.js')); ?>"></script>
      
      <script src="<?php echo e(asset('c_assets/js/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('c_assets/js/bootstrap.min.js')); ?>"></script>
      <!-- Appear JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/jquery.appear.js')); ?>"></script>
      <!-- Countdown JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/countdown.min.js')); ?>"></script>
      <!-- Counterup JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/waypoints.min.js')); ?>"></script>
      <script src="<?php echo e(asset('c_assets/js/jquery.counterup.min.js')); ?>"></script>
      <!-- Wow JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/wow.min.js')); ?>"></script>
      <!-- Apexcharts JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/apexcharts.js')); ?>"></script>
      <!-- Slick JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/slick.min.js')); ?>"></script>
      <!-- Select2 JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/select2.min.js')); ?>"></script>
            <!-- Owl Carousel JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/owl.carousel.min.js')); ?>"></script>
      <!-- Magnific Popup JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/jquery.magnific-popup.min.js')); ?>"></script>
      <!-- Smooth Scrollbar JavaScript -->
      <script src="j<?php echo e(asset('c_assets/js/smooth-scrollbar.js')); ?>"></script>
      <!-- lottie JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/lottie.js')); ?>"></script>
      <!-- am core JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/core.js')); ?>"></script>
      <!-- am charts JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/charts.js')); ?>"></script>
      <!-- am animated JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/animated.js')); ?>"></script>
      <!-- am kelly JavaScript -->
      <script src="<?php echo e(asset('js/kelly.js')); ?>"></script>
      <!-- Morris JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/morris.js')); ?>"></script>
      <!-- am maps JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/maps.js')); ?>"></script>
      <!-- am worldLow JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/worldLow.js')); ?>"></script>
      <!-- ChartList Js -->
      <script src="<?php echo e(asset('c_assets/js/chartist/chartist.min.js')); ?>"></script>
      <!-- Chart Custom JavaScript -->
      <script async src="<?php echo e(asset('c_assets/js/chart-custom.js')); ?>"></script>
      <!-- Custom JavaScript -->
      <script src="<?php echo e(asset('c_assets/js/custom.js')); ?>"></script>
      <script>

                 /*---------------------------------------------------------------------
        Page Menu
        -----------------------------------------------------------------------*/
        jQuery(document).on('click', '.wrapper-menu', function() {
            jQuery(this).toggleClass('open');
        });

        jQuery(document).on('click', ".wrapper-menu", function() {
            jQuery("body").toggleClass("sidebar-main");
        });
      </script>
   </body>
</html>
<?php /**PATH C:\xampp\htdocs\ubithsil.com\resources\views/mydesk/template/footer.blade.php ENDPATH**/ ?>