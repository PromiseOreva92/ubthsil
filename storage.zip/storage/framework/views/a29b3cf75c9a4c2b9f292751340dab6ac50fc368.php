<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main id="main" class="mt-5 pt-5">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>ID-CAPITALS</h2>
          <p>About US </p>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-8">
            <p>
            Since their inception, cryptocurrencies have taken the financial world by storm. With untold potential and incredible upside, investors around the world are seeking ways to capitalize on the technology powering these innovative currencies. For newcomers to the field or seasoned veterans, there is one company that stands out from the rest: ID-CAPITALS Investments.
            </p>

            <p>
            Founded by a team of cutting-edge cryptocurrency experts, ID-CAPITALS has quickly positioned itself as a leader in the investment world. Through its cutting-edge investment strategies and innovative approach to the market, ID-CAPITALS is unlocking the power of cryptocurrencies for investors of all levels
            </p>

            <p>
            At the heart of ID-CAPITALS are its investment strategies. Leveraging the latest technology and analytical tools, the team at ID-CAPITALS has developed a proprietary system for identifying the most promising cryptocurrencies and investment opportunities. From high-growth assets to stable investments, ID-CAPITALS is actively seeking out the very best options for their clients.
            </p>

            <p>
            Beyond its innovative strategies, ID-CAPITALS is known for its world-class customer service. With a team of experienced professionals standing by, investors can rest assured that they will receive prompt and attentive support whenever it is needed. Whether it is answering questions or providing updates on the latest investment opportunities, the team at ID-CAPITALS is there to assist every step of the way
            </p>

            <p>
            Finally, ID-CAPITALS is dedicated to transparency, security, and trust. With so many cryptocurrency investment companies out there, ID-CAPITALS sets itself apart through its commitment to honesty and integrity. Every investment opportunity is thoroughly vetted and analyzed before it is presented to investors, ensuring that every investment aligns with the company's strict standards for quality and reliability.
            </p>
            <p>
            In all, ID-CAPITALS Investments is the perfect choice for those seeking to capitalize on the potential of cryptocurrencies. With its innovative investment strategies, excellent customer service, and unwavering commitment to ethics and transparency, it is clear that ID-CAPITALS is unlocking the power of cryptocurrencies for investors everywhere
            </p>
          </div>

        </div>

      </div>
    </section><!-- End About Section -->

  </main><!-- End #main -->
  <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/about.blade.php ENDPATH**/ ?>