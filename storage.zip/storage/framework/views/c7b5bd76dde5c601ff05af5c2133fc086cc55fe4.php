<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <main id="main" class="mt-5">
    <section id="about" class="reg">
        <div class="container" data-aos="fade-up">
  
          
  
          <div class="row content justify-content-center">
            <div class="col-lg-5 pt-4 pt-lg-0 shadow-lg">
              <form class="m-md-4 mt-sm-4" action="<?php echo e(route('otp_check')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="section-title">
                    <h2>User Check</h2>
                    <p>An OTP Code has been sent to your email. Check Your inbox or spam folder</p>
                  </div>

                  <?php if(session()->has('message')): ?> 
                    <div class="alert alert-primary alert-dismissible fade show" role="alert">
                      <Strong><?php echo e(session()->get('message')); ?></strong>
                    </div>                               
                  <?php endif; ?>
                  <div class="form-floating mb-3 border border-su">
                    <input type="text" name="otp" class="form-control" id="floatingInput" placeholder="name@example.com" required="">
                    <label for="floatingInput">Enter Your OTP code</label>
                  </div>
                             
                  


                  <div class="row mt-3">
                    

                    <div class="d-grid gap-2 d-md-block mt-2">
                      <button type="submit" class="btn btn-success btn-block btn-lg col-12" style="color:#fed700">SUBMIT</button>
                    </div>


                    

                  </div>

              </form>

            </div>
          </div>
  
        </div>
      </section><!-- End About Section -->
  </main>




 <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rdcm\resources\views/factor-auth.blade.php ENDPATH**/ ?>